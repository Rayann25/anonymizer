"""Banc de test : compare les configurations de détection et les classifieurs
de sensibilité sur un jeu FICTIF annoté à la main.

    python -m eval.run_eval                # lexical + zero-shot si disponible
    python -m eval.run_eval --no-zeroshot  # plus rapide
    TYPESAFE_API_KEY=... python -m eval.run_eval   # ajoute Jev

Écrit eval/report.json (affiché dans l'onglet « Banc de test »).
"""
from __future__ import annotations

import argparse
import asyncio
import json
import time
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")

from app.config import settings  # noqa: E402
from app.detection.engine import Detector  # noqa: E402
from app.sensitivity.classifiers import CLASSIFIERS  # noqa: E402
from app.sensitivity.policy import VERY, decide  # noqa: E402

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"


def load(name):
    return [json.loads(line) for line in (DATA / name).read_text().splitlines() if line.strip()]


# ------------------------------------------------------------------ détection
def eval_detection(det: Detector, items: list[dict], label: str) -> dict:
    gold_total = found = partial = tp_spans = all_spans = 0
    per_type: dict[str, dict] = {}
    misses = []
    t0 = time.perf_counter()
    for it in items:
        text = it["text"]
        spans = det.detect(text, None)
        all_spans += len(spans)
        gold_ranges = []
        for value, etype in it["entities"]:
            start = text.find(value)
            assert start >= 0, (it["id"], value)
            end = start + len(value)
            gold_ranges.append((start, end))
            gold_total += 1
            pt = per_type.setdefault(etype, {"gold": 0, "found": 0})
            pt["gold"] += 1
            covering = [s for s in spans if s.start <= start and s.end >= end]
            touching = [s for s in spans if s.end > start and s.start < end]
            if covering:
                found += 1
                pt["found"] += 1
            elif touching:
                partial += 1  # masqué en partie seulement : fuite partielle
                misses.append({"what": f"{value} ({etype}) masqué en partie", "where": it["id"], "config": label})
            else:
                misses.append({"what": f"{value} ({etype})", "where": it["id"], "config": label})
        for s in spans:
            if any(s.end > a and s.start < b for a, b in gold_ranges):
                tp_spans += 1
    ms = (time.perf_counter() - t0) * 1000 / len(items)
    for v in per_type.values():
        v["recall"] = round(v["found"] / v["gold"], 3) if v["gold"] else None
    return {"config": label, "recall": round(found / gold_total, 3), "precision": round(tp_spans / all_spans, 3) if all_spans else None,
            "partial_leaks": partial, "ms_per_message": round(ms, 1), "per_type": per_type, "misses": misses}


# ------------------------------------------------------------------ sensibilité
def expected_action(item: dict) -> str:
    if not item["cats"]:
        return "garder"
    very = any(c in VERY for c in item["cats"])
    if very:
        return "bloquer" if item["necessary"] else "retirer"
    return "generaliser" if item["necessary"] else "retirer"


async def eval_classifier(name: str, items: list[dict], note: str | None = None, preds: dict | None = None) -> dict:
    t0 = time.perf_counter()
    if preds is None:
        clf = CLASSIFIERS[name]
        by_profile: dict[str, list[dict]] = {}
        for it in items:
            by_profile.setdefault(it["profile"], []).append(it)
        preds = {}
        for profile, its in by_profile.items():
            res = await clf.classify([i["text"] for i in its], profile, [])
            for i, r in zip(its, res):
                preds[i["id"]] = r
        ms = (time.perf_counter() - t0) * 1000 / len(items)
    else:
        ms = sum(p["latency_ms"] for p in preds.values()) / len(items)
    errors = sum(1 for r in preds.values() if r.get("error"))
    if errors == len(items):
        return {"classifier": name, "note": f"erreur : {next(iter(preds.values()))['error'][:80]}",
                "recall_explicit": None, "recall_implicit": None, "over_masking": None,
                "decision_accuracy": None, "ms_per_segment": None, "misses": []}

    def flagged(r):
        return decide(r)["action"] != "garder"

    exp = [i for i in items if i["cats"] and not i["implicit"]]
    imp = [i for i in items if i["cats"] and i["implicit"]]
    neu = [i for i in items if not i["cats"]]
    ok = sum(1 for i in items if decide(preds[i["id"]])["action"] == expected_action(i))
    misses = [{"what": f"« {i['text']} » ({', '.join(i['cats'])}{', implicite' if i['implicit'] else ''})",
               "where": f"{i['id']} — {name}"} for i in exp + imp if not flagged(preds[i["id"]])]
    misses += [{"what": f"« {i['text']} » signalé à tort", "where": f"{i['id']} — {name}"}
               for i in neu if flagged(preds[i["id"]])]
    # balayage du seuil : rappel et sur-masquage selon le seuil de détection
    def max_cat(i):
        return max(preds[i["id"]]["categories"].values())
    sweep = []
    for t in [0.35, 0.5, 0.65, 0.8, 0.9, 0.95, 0.98]:
        sweep.append({"threshold": t,
                      "recall_explicit": round(sum(max_cat(i) >= t for i in exp) / len(exp), 3),
                      "recall_implicit": round(sum(max_cat(i) >= t for i in imp) / len(imp), 3),
                      "over_masking": round(sum(max_cat(i) >= t for i in neu) / len(neu), 3)})
    (HERE / f"preds_{name}.json").write_text(json.dumps(preds, ensure_ascii=False))
    return {
        "classifier": name, "note": note, "threshold_sweep": sweep,
        "recall_explicit": round(sum(flagged(preds[i["id"]]) for i in exp) / len(exp), 3),
        "recall_implicit": round(sum(flagged(preds[i["id"]]) for i in imp) / len(imp), 3),
        "over_masking": round(sum(flagged(preds[i["id"]]) for i in neu) / len(neu), 3),
        "decision_accuracy": round(ok / len(items), 3),
        "ms_per_segment": round(ms, 1),
        "misses": misses,
    }


def run_detection(report, det_items, args):
    import gc

    print("Détection…")
    configs = [("Presidio standard (spaCy fr)", False, False)]
    gliner_model = None
    if not args.no_gliner:
        from gliner import GLiNER
        gliner_model = GLiNER.from_pretrained(settings.gliner_model)
        configs.append(("Presidio standard + GLiNER", True, False))
    configs.append(("Presidio + détecteurs FR métier", False, True))
    if not args.no_gliner:
        configs.append(("Presidio + détecteurs FR + GLiNER", True, True))
    report["detection"] = []
    for label, g, fr in configs:
        det = Detector(use_gliner=g, use_custom_fr=fr, gliner_model=gliner_model)
        det.detect("échauffement", None)
        r = eval_detection(det, det_items, label)
        print(f"  {label:38s} rappel {r['recall']:.1%}  précision {r['precision']:.1%}  fuites partielles {r['partial_leaks']}")
        report["detection"].append(r)
        del det
        gc.collect()



async def main(args):
    det_items = load("detection.jsonl")
    sens_items = load("sensitivity.jsonl")
    report = {"generated_at": time.strftime("%Y-%m-%d %H:%M"), "dataset": {
        "messages": len(det_items), "entities": sum(len(i["entities"]) for i in det_items),
        "sensitive_segments": sum(1 for i in sens_items if i["cats"]),
        "neutral_segments": sum(1 for i in sens_items if not i["cats"])}}

    previous = HERE / "report.json"
    if args.sensitivity_only and previous.exists():
        report["detection"] = json.loads(previous.read_text())["detection"]
        print("Détection : mesures reprises du rapport précédent.")
    else:
        run_detection(report, det_items, args)

    print("Couche sens…")
    report["sensitivity"] = []
    report["sensitivity"].append(await eval_classifier("lexical", sens_items,
                                                       "lexique écrit en voyant une partie des exemples : biais favorable"))
    if not args.no_zeroshot:
        zs = await eval_classifier("zeroshot", sens_items, "mDeBERTa-XNLI, sans entraînement, seuil par défaut")
        report["sensitivity"].append(zs)
        if zs["recall_explicit"] is not None:
            from app.catalog import BUSINESS_PROFILES
            from app.sensitivity.classifiers import HybridClassifier
            lx = json.loads((HERE / "preds_lexical.json").read_text())
            zp = json.loads((HERE / "preds_zeroshot.json").read_text())
            prof = {i["id"]: set(BUSINESS_PROFILES[i["profile"]]["needed"]) for i in sens_items}
            hy = {k: HybridClassifier.combine(lx[k], zp[k], prof[k]) for k in lx}
            report["sensitivity"].append(await eval_classifier(
                "hybride", sens_items, "lexique + zero-shot retenu au-delà de 0,95", preds=hy))
    if settings.jev_api_key:
        report["sensitivity"].append(await eval_classifier("jev", sens_items, "texte pseudonymisé uniquement"))
    else:
        report["sensitivity"].append({"classifier": "jev", "note": "non mesuré : TYPESAFE_API_KEY absente",
                                      "recall_explicit": None, "recall_implicit": None, "over_masking": None,
                                      "decision_accuracy": None, "ms_per_segment": None, "misses": []})
    for s in report["sensitivity"]:
        if s["recall_explicit"] is not None:
            print(f"  {s['classifier']:10s} explicite {s['recall_explicit']:.1%}  implicite {s['recall_implicit']:.1%}  "
                  f"sur-masquage {s['over_masking']:.1%}  bonne décision {s['decision_accuracy']:.1%}")
        else:
            print(f"  {s['classifier']:10s} {s['note']}")

    best = report["detection"][-1]
    report["misses"] = best["misses"] + [m for s in report["sensitivity"] for m in s.get("misses", [])]
    (HERE / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print("Rapport :", HERE / "report.json")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-gliner", action="store_true")
    ap.add_argument("--no-zeroshot", action="store_true")
    ap.add_argument("--sensitivity-only", action="store_true", help="reprend la détection du rapport existant")
    asyncio.run(main(ap.parse_args()))
