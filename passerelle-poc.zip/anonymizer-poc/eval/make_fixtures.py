"""Génère des contrats FICTIFS en PDF : un natif et un « scanné » (image seule),
avec signature manuscrite et tampon dessinés. Aucune donnée réelle.

    python -m eval.make_fixtures
"""
from __future__ import annotations

import io
import math
import random
from pathlib import Path

import fitz
from PIL import Image, ImageFilter

OUT = Path(__file__).resolve().parent / "data"

CONTRACT = """CONTRAT D'ASSURANCE HABITATION — CONDITIONS PARTICULIÈRES
Contrat n° HAB-2025-004417          Police n° POL-77-112233

Entre la société Assurances du Littoral, SIRET 732 829 320 00074, ci-après « l'Assureur »,
et Madame Claire Martin, née le 4 mai 1979, demeurant 27 avenue du Prado, 13008 Marseille,
téléphone 06 45 87 21 09, e-mail claire.martin@exemple.fr, ci-après « l'Assurée ».

Article 1 — Objet. Le présent contrat garantit la résidence principale de l'Assurée
contre l'incendie, le dégât des eaux, le vol et la responsabilité civile.

Article 2 — Cotisation. La cotisation annuelle de 412,80 euros est prélevée chaque mois
sur le compte IBAN FR76 1027 8090 0100 0204 5670 128, BIC CMCIFR2A.

Article 3 — Durée. Le contrat prend effet le 1er février 2025 pour une durée d'un an,
renouvelable par tacite reconduction. Client n° CLI-558902.

Article 4 — Résiliation. L'Assurée peut résilier à tout moment après un an,
par lettre ou e-mail adressé à son conseiller, M. Paul Lefèvre.

Fait à Marseille, le 15 janvier 2025, en deux exemplaires.

Signature de l'Assurée                              Pour l'Assureur
Lu et approuvé
"""


def _signature(page: fitz.Page, x: float, y: float, seed: int):
    rnd = random.Random(seed)
    shape = page.new_shape()
    pts = []
    for i in range(40):
        t = i / 39
        pts.append(fitz.Point(x + t * 150, y + 18 * math.sin(t * 9 + seed) + rnd.uniform(-6, 6)))
    for a, b, c in zip(pts[::2], pts[1::2], pts[2::2]):
        shape.draw_bezier(a, b, b, c)
    shape.finish(color=(0.05, 0.1, 0.45), width=1.4)
    shape.commit()


def _stamp(page: fitz.Page, center: fitz.Point):
    shape = page.new_shape()
    shape.draw_circle(center, 34)
    shape.draw_circle(center, 27)
    shape.finish(color=(0.6, 0.1, 0.1), width=1.6)
    shape.commit()
    page.insert_text(center + (-24, 3), "ASSUREUR", fontsize=8, color=(0.6, 0.1, 0.1))


def native() -> bytes:
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    y = 60
    for line in CONTRACT.splitlines():
        page.insert_text((50, y), line, fontsize=9.5 if not line.isupper() else 11, fontname="helv")
        y += 15
    sig_y = y + 18
    _signature(page, 55, sig_y, 3)
    _signature(page, 360, sig_y, 7)
    _stamp(page, fitz.Point(480, sig_y + 5))
    data = doc.tobytes()
    doc.close()
    return data


def scanned(native_pdf: bytes) -> bytes:
    src = fitz.open(stream=native_pdf, filetype="pdf")
    pix = src[0].get_pixmap(matrix=fitz.Matrix(200 / 72, 200 / 72), colorspace=fitz.csGRAY)
    img = Image.open(io.BytesIO(pix.tobytes("png"))).rotate(0.6, fillcolor=255, expand=False)
    img = img.filter(ImageFilter.GaussianBlur(0.6))
    rnd = random.Random(1)
    px = img.load()
    for _ in range(4000):  # grain de numérisation
        x, y = rnd.randrange(img.width), rnd.randrange(img.height)
        px[x, y] = max(0, px[x, y] - rnd.randrange(60, 140))
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=70)
    doc = fitz.open()
    page = doc.new_page(width=595, height=842)
    page.insert_image(page.rect, stream=buf.getvalue())
    data = doc.tobytes()
    doc.close()
    src.close()
    return data


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    n = native()
    (OUT / "contrat_fictif_natif.pdf").write_bytes(n)
    (OUT / "contrat_fictif_scanne.pdf").write_bytes(scanned(n))
    print("PDF fictifs écrits dans", OUT)
