---
title: Passerelle de confiance
emoji: 🔏
colorFrom: blue
colorTo: green
sdk: docker
app_port: 7860
pinned: false
short_description: POC de pseudonymisation avant LLM (données fictives uniquement)
---

# Passerelle de confiance — POC de pseudonymisation avant LLM

Microservice qui empêche les données personnelles et sensibles d'atteindre un LLM externe, puis restitue les réponses en clair. Deux usages :

- **Documents** : un PDF (contrat signé, scanné ou natif) est analysé, masqué, envoyé au LLM sous forme protégée, et la réponse revient avec les vraies valeurs. Le PDF masqué est téléchargeable, signatures et tampons effacés.
- **Chatbot** : chaque message client (« je suis endetté », « ma femme m'a quitté ») est protégé. Selon le métier du service, chaque proposition sensible est gardée, généralisée, retirée, ou le message entier est bloqué pour le LLM externe.

## Démarrer

```bash
pip install -r requirements.txt
python -m spacy download fr_core_news_md
cp .env.example .env            # clés facultatives
./run.sh                        # API + interface : http://localhost:8000   (docs : /docs)
streamlit run streamlit_app.py  # ou version Streamlit : http://localhost:8501
```

Tesseract avec le français est requis pour les PDF scannés (`apt install tesseract-ocr tesseract-ocr-fra`, ou le fichier `models/tessdata/fra.traineddata` fourni).

Sans aucune clé, tout fonctionne en local : classifieur lexical et **LLM simulé** (étiqueté comme tel). Ajouter `MISTRAL_API_KEY` pour un vrai LLM, `TYPESAFE_API_KEY` pour Jev.

## Mettre en ligne gratuitement (Streamlit Community Cloud)

1. Mettre ce dossier dans un dépôt GitHub (le contenu du dossier à la racine du dépôt).
2. Sur share.streamlit.io : **Create app**, choisir le dépôt, la branche `main`, le fichier `streamlit_app.py`.
3. Dans **Advanced settings** : Python 3.11, et dans **Secrets**, au besoin :
   ```toml
   MISTRAL_API_KEY = "…"
   TYPESAFE_API_KEY = "…"
   ```
4. Déployer. Première installation : 5 à 10 minutes (modèles). `packages.txt` installe Tesseract pour l'OCR.

Si l'application manque de mémoire, ajouter le secret `USE_GLINER = "0"` (détection sans GLiNER, rappel plus faible). Le classifieur zero-shot / hybride est désactivé en ligne par défaut (`ENABLE_ZEROSHOT = "1"` pour l'activer).

## Architecture

```
Texte / PDF ──► extraction (texte natif ou OCR, position de chaque mot)
           ──► 1. Détection locale : Presidio + détecteurs FR métier + GLiNER
           ──► 2. Pseudonymes typés et cohérents  [PERSONNE_1]   (table chiffrée AES-256-GCM)
           ──► 3. Couche sens, sur le texte DÉJÀ pseudonymisé : découpage en propositions,
                  classifieur (lexical | Jev | zero-shot | Ollama) → catégories, intensité, nécessité
           ──► 4. Règle de décision  sensibilité × nécessité à la tâche  → route
                  externe (Mistral)  |  local (Ollama)  |  humain (conseiller)
           ──► 5. Restitution tolérante + contrôle des fuites à l'envers
```

| Fichier | Rôle |
|---|---|
| `app/detection/recognizers_fr.py` | Détecteurs Presidio français : téléphone, NIR, SIRET (Luhn), dates en lettres, adresses, références « contrat n° … » |
| `app/detection/engine.py` | Presidio + GLiNER, nettoyage : entité complète (pas de fuite partielle), rôles contractuels filtrés, chevauchements résolus |
| `app/pseudonymizer.py` | Jetons cohérents (« Dupont » = « Jean Dupont »), généralisation (tranche d'âge, département, région) |
| `app/vault.py` | Table de correspondance chiffrée, durée de vie limitée, lecture journalisée |
| `app/sensitivity/` | Découpage, classifieurs interchangeables, règle de décision |
| `app/pdf.py` | Extraction, OCR, masquage réel du texte, effacement de l'encre sous les intitulés de signature |
| `app/restore.py` | Restitution (variantes de jetons), jetons inventés, fuites à l'envers |
| `app/main.py` | API FastAPI + interface |
| `eval/` | Jeu fictif annoté, génération de PDF fictifs, banc de test |

## Réponses à la liste de tâches

| Tâche | Où |
|---|---|
| Sélectionner à l'appel les infos à pseudonymiser | `POST /api/pseudonymize` : `entities` (types), `strategies` (jeton, généraliser, supprimer, conserver), `sensitive.business_context` |
| Récupérer la table de correspondance | `GET /api/mapping/{session}` avec l'en-tête `X-Mapping-Token`, lecture journalisée |
| Comparer Jev / équivalent | `sensitive.classifier = jev` (API TypeSafe `v1/systemone`, questions `noul` + `score`) ; comparé au lexical et au zero-shot local dans `eval/run_eval.py` |
| Modèle entraîné sur docs de signature | Prévu en phase 4 : le banc de test et le format de données sont prêts pour comparer |
| GLiNER | Branché dans Presidio comme détecteur ; mesuré seul et combiné dans le banc de test |

## Garanties testées (`USE_GLINER=0 pytest -q`)

- Aucun numéro masqué en partie (l'ancien POC laissait passer `-8891`).
- Aucun identifiant ni mot sensible dans le texte envoyé.
- Même personne = même jeton, quelles que soient ses variantes.
- La décision dépend du métier : « endetté » est retiré en gestion de contrats, généralisé en recouvrement.
- Santé nécessaire → LLM externe bloqué ; détresse → conseiller.
- Un utilisateur qui tape lui-même `[PERSONNE_1]` ne récupère jamais la valeur réelle (injection de jetons neutralisée).
- La table est chiffrée en mémoire, son accès exige un jeton et laisse une trace.
- Dans le PDF masqué, le texte est supprimé du fichier, pas seulement recouvert.

## Résultats du banc de test (`python -m eval.run_eval`)

Jeu fictif : 40 messages et extraits de contrats (74 entités annotées), 70 propositions pour la couche sens (45 sensibles, dont 16 implicites, et 25 neutres).

| Détection | Rappel | Précision | Fuites partielles |
|---|---|---|---|
| Presidio standard (spaCy fr) | 45,9 % | 94,1 % | 9 |
| Presidio standard + GLiNER | 89,2 % | 91,8 % | 1 |
| Presidio + détecteurs FR métier | 86,5 % | 93,0 % | 2 |
| **Presidio + détecteurs FR + GLiNER** | **100 %** | 91,4 % | **0** |

| Couche sens | Explicite | Implicite | Sur-masquage | Bonne décision |
|---|---|---|---|---|
| Lexical (référence, biais favorable) | 93,1 % | 31,2 % | 8,0 % | 74,3 % |
| Zero-shot mDeBERTa, seuil par défaut | 69,0 % | 75,0 % | 64,0 % | 50,0 % |
| **Hybride (lexique + zero-shot > 0,95)** | **96,6 %** | **62,5 %** | 16,0 % | **78,6 %** |
| Jev | à mesurer avec `TYPESAFE_API_KEY` | | | |

Lecture : GLiNER et les détecteurs français se complètent (aucun des deux seul ne dépasse 90 %). Pour le sens, le zero-shot comprend l'implicite mais ses probabilités sont mal calibrées : c'est précisément ce que Jev annonce corriger, et ce que le banc de test permettra de vérifier.

## Limites connues du POC

- La détection des signatures est une heuristique (encre hors texte sous un intitulé « Signature », « Lu et approuvé »…). Un détecteur d'objets entraîné doit la remplacer.
- Le classifieur lexical sert d'étalon ; il rate la majorité des formulations implicites (voir le banc de test).
- Les seuils (0,35 / 0,65) et les profils métier sont des valeurs de départ à régler sur vos données.
- Le jeu de test est petit et fictif : il sert à comparer des configurations, pas à certifier un taux.
- Sessions en mémoire : un redémarrage efface les tables (voulu pour le POC).
