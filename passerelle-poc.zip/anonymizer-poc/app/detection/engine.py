"""Moteur de détection : Presidio (socle) + GLiNER (complément), puis
nettoyage des résultats pour garantir des entités complètes et cohérentes."""
from __future__ import annotations

import logging
import re
import threading
import time
from dataclasses import asdict, dataclass

from presidio_analyzer import AnalyzerEngine, EntityRecognizer, RecognizerRegistry, RecognizerResult
from presidio_analyzer.nlp_engine import NlpEngineProvider
from presidio_analyzer.predefined_recognizers import (
    CreditCardRecognizer,
    EmailRecognizer,
    IbanRecognizer,
    IpRecognizer,
    SpacyRecognizer,
)

from ..config import settings
from .recognizers_fr import LANG, KeyedReferenceRecognizer, StandaloneCodeRecognizer, build_pattern_recognizers

log = logging.getLogger(__name__)

# Noms Presidio -> noms du catalogue
PRESIDIO_MAP = {
    "EMAIL_ADDRESS": "EMAIL", "IBAN_CODE": "IBAN", "CREDIT_CARD": "CARTE_BANCAIRE",
    "IP_ADDRESS": "IP", "PERSON": "PERSONNE", "LOCATION": "LIEU", "ORGANIZATION": "ORGANISATION",
}

GLINER_LABELS = {
    "person": "PERSONNE",
    "organization": "ORGANISATION",
    "address": "ADRESSE",
    "city": "LIEU",
    "phone number": "TELEPHONE",
    "email": "EMAIL",
    "date of birth": "DATE_NAISSANCE",
    "contract number": "NUM_CONTRAT",
    "insurance policy number": "NUM_POLICE",
    "iban": "IBAN",
    "social security number": "NIR",
    "passport number": "PIECE_IDENTITE",
}

# Types pour lesquels on étend la détection jusqu'aux blancs (entité complète)
ID_TYPES = {"IBAN", "BIC", "CARTE_BANCAIRE", "NUM_CONTRAT", "NUM_POLICE", "NUM_CLIENT", "NUM_DOSSIER",
            "PLAQUE", "PIECE_IDENTITE", "EMAIL", "IP"}
# En cas de chevauchement à score proche, le type le plus spécifique l'emporte
SPECIFICITY = {
    "IBAN": 10, "NIR": 10, "CARTE_BANCAIRE": 10, "SIRET": 9, "EMAIL": 9, "TELEPHONE": 9, "BIC": 8,
    "NUM_CONTRAT": 8, "NUM_POLICE": 8, "NUM_CLIENT": 8, "PIECE_IDENTITE": 8, "PLAQUE": 8,
    "DATE_NAISSANCE": 8, "ADRESSE": 7, "NUM_DOSSIER": 6, "DATE": 5, "PERSONNE": 5, "IP": 5,
    "ORGANISATION": 3, "LIEU": 2,
}
TITLES = re.compile(r"^(?:M\.|Mr\.?|Mme\.?|Mlle\.?|Me\.?|Dr\.?|Monsieur|Madame|Mademoiselle|Ma[iî]tre|Docteur)\s+", re.I)
NOISE = {
    "bonjour", "bonsoir", "merci", "cordialement", "madame", "monsieur", "client", "le client", "contrat",
    "iban", "bic", "tel", "tél", "mail", "e-mail", "je", "objet", "signature", "lu et approuvé", "fait",
    "conditions générales", "conditions particulières", "souscripteur", "assuré", "assureur", "article",
    "la banque", "banque", "société", "mon conseiller", "date", "dépression",
}
# Rôles contractuels que spaCy prend souvent pour des noms propres
ROLE_WORDS = re.compile(
    r"(?i)\b(?:l'|la |le |les )?(?:assur[ée]e?s?|assureur|souscripteur|b[ée]n[ée]ficiaire|signature|client|conseiller|"
    r"pr[êe]teur|emprunteur|bailleur|locataire|mandataire|vendeur|acheteur|soci[ée]t[ée]|article|contrat|lu|approuv[ée])\b"
)
BIRTH_CONTEXT = re.compile(r"(?i)(\bn[ée]e?\s+le|date\s+de\s+naissance|naissance\s*:|né\(e\)\s+le)\s*:?\s*$")


@dataclass
class Span:
    start: int
    end: int
    type: str
    score: float
    source: str
    text: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class GlinerRecognizer(EntityRecognizer):
    """GLiNER branché comme détecteur Presidio supplémentaire."""

    def __init__(self, model):
        super().__init__(supported_entities=sorted(set(GLINER_LABELS.values())), supported_language=LANG,
                         name="GlinerRecognizer")
        self.model = model

    def load(self):
        return None

    @staticmethod
    def _chunks(text: str, size: int = 1000):
        start = 0
        while start < len(text):
            end = min(len(text), start + size)
            if end < len(text):
                cut = max(text.rfind(". ", start, end), text.rfind("\n", start, end))
                if cut > start + size // 2:
                    end = cut + 1
            yield start, text[start:end]
            start = end

    def analyze(self, text, entities, nlp_artifacts=None):
        wanted = [lbl for lbl, ent in GLINER_LABELS.items() if not entities or ent in entities]
        out = []
        for offset, chunk in self._chunks(text):
            for ent in self.model.predict_entities(chunk, wanted, threshold=settings.gliner_threshold):
                out.append(RecognizerResult(GLINER_LABELS[ent["label"]], offset + ent["start"],
                                            offset + ent["end"], float(ent["score"])))
        return out


class Detector:
    def __init__(self, use_gliner: bool | None = None, use_custom_fr: bool = True, gliner_model=None):
        self.use_gliner = settings.use_gliner if use_gliner is None else use_gliner
        self.use_custom_fr = use_custom_fr  # False = Presidio « standard » (banc de test)
        self._gliner_model = gliner_model
        self.gliner_status = "désactivé"
        self._build()

    def _build(self):
        provider = NlpEngineProvider(nlp_configuration={
            "nlp_engine_name": "spacy",
            "models": [{"lang_code": LANG, "model_name": settings.spacy_model}],
            "ner_model_configuration": {
                "model_to_presidio_entity_mapping": {"PER": "PERSON", "LOC": "LOCATION", "ORG": "ORGANIZATION"},
                "labels_to_ignore": ["MISC"],
                "low_score_entity_names": ["ORG"],
                "low_confidence_score_multiplier": 0.6,
            },
        })
        nlp_engine = provider.create_engine()
        registry = RecognizerRegistry(supported_languages=[LANG])
        registry.add_recognizer(SpacyRecognizer(supported_language=LANG,
                                                supported_entities=["PERSON", "LOCATION", "ORGANIZATION"]))
        registry.add_recognizer(EmailRecognizer(supported_language=LANG))
        registry.add_recognizer(IbanRecognizer(supported_language=LANG, context=["iban", "rib", "compte"]))
        registry.add_recognizer(CreditCardRecognizer(supported_language=LANG, context=["carte", "cb", "visa", "mastercard"]))
        registry.add_recognizer(IpRecognizer(supported_language=LANG))
        if self.use_custom_fr:
            for rec in build_pattern_recognizers():
                registry.add_recognizer(rec)
            registry.add_recognizer(KeyedReferenceRecognizer())
            registry.add_recognizer(StandaloneCodeRecognizer())

        if self.use_gliner:
            try:
                from gliner import GLiNER

                t0 = time.time()
                model = self._gliner_model or GLiNER.from_pretrained(settings.gliner_model)
                self.gliner_model = model
                registry.add_recognizer(GlinerRecognizer(model))
                self.gliner_status = f"chargé ({settings.gliner_model}, {time.time() - t0:.0f} s)"
            except Exception as exc:  # pragma: no cover - dépend de l'environnement
                log.warning("GLiNER indisponible : %s", exc)
                self.gliner_status = f"indisponible ({type(exc).__name__})"
        self.analyzer = AnalyzerEngine(nlp_engine=nlp_engine, registry=registry, supported_languages=[LANG])

    # ------------------------------------------------------------------ public
    def detect(self, text: str, entities: list[str] | None = None) -> list[Span]:
        raw = self.analyzer.analyze(text=text, language=LANG)
        spans = []
        for r in raw:
            etype = PRESIDIO_MAP.get(r.entity_type, r.entity_type)
            source = (r.recognition_metadata or {}).get("recognizer_name", "presidio")
            spans.append(Span(r.start, r.end, etype, round(float(r.score), 3), source))
        spans = self._clean(text, spans)
        if entities is not None:
            spans = [s for s in spans if s.type in entities]
        for s in spans:
            s.text = text[s.start:s.end]
        return spans

    # --------------------------------------------------------------- nettoyage
    def _clean(self, text: str, spans: list[Span]) -> list[Span]:
        cleaned: list[Span] = []
        for s in spans:
            if s.score < 0.3:
                continue
            seg = text[s.start:s.end]
            # titres hors du nom : « M. Dupont » -> « Dupont »
            if s.type == "PERSONNE":
                m = TITLES.match(seg)
                if m:
                    s.start += m.end()
                    seg = text[s.start:s.end]
            # espaces et ponctuation en bordure
            while s.end > s.start and text[s.end - 1] in " \n\t,;:.)(\"'":
                s.end -= 1
            while s.start < s.end and text[s.start] in " \n\t,;:.)(\"'":
                s.start += 1
            seg = text[s.start:s.end]
            if not seg or seg.lower() in NOISE:
                continue
            if s.type in {"PERSONNE", "ORGANISATION", "LIEU"}:
                if "\n" in seg:  # une entité nommée ne traverse pas une ligne
                    s.end = s.start + seg.index("\n")
                    seg = text[s.start:s.end].rstrip()
                    s.end = s.start + len(seg)
                gliner_sure = "Gliner" in s.source and s.score >= 0.6
                # spaCy seul sur un mot en minuscules = bruit ; GLiNER, lui, gère les chats sans majuscules
                if len(seg) < 2 or seg.lower() in NOISE or (seg.islower() and not gliner_sure):
                    continue
                # « l'Assurée », « Pour l'Assureur » : rôle, pas personne (sauf si GLiNER est sûr)
                if ROLE_WORDS.search(seg) and not (gliner_sure and s.score >= 0.8):
                    continue
            # entité complète pour les identifiants
            if s.type in ID_TYPES:
                while s.start > 0 and not text[s.start - 1].isspace() and text[s.start - 1] not in ",;:(\"'«":
                    s.start -= 1
                while s.end < len(text) and not text[s.end].isspace() and text[s.end] not in ",;:)\"'»":
                    s.end += 1
                while s.end > s.start and text[s.end - 1] in ".":
                    s.end -= 1
            # date de naissance selon le contexte
            if s.type == "DATE" and BIRTH_CONTEXT.search(text[max(0, s.start - 30):s.start]):
                s.type, s.score = "DATE_NAISSANCE", max(s.score, 0.85)
            cleaned.append(s)
        return self._resolve_overlaps(cleaned)

    @staticmethod
    def _resolve_overlaps(spans: list[Span]) -> list[Span]:
        """Un passage = une seule entité. Inclusion : la plus large gagne, sauf
        si l'incluse est nettement plus spécifique (ex. IBAN dans une ligne
        attrapée à tort comme organisation). Chevauchement partiel : union."""
        def rank(s: Span):
            return (SPECIFICITY.get(s.type, 1) + s.score * 4, s.end - s.start)

        spans = sorted(spans, key=lambda s: (s.start, -(s.end - s.start)))
        result: list[Span] = []
        for s in spans:
            merged = False
            for i, r in enumerate(result):
                if s.start >= r.end or s.end <= r.start:
                    continue
                winner = max((r, s), key=rank)
                contains = (r.start <= s.start and r.end >= s.end) or (s.start <= r.start and s.end >= r.end)
                if contains:
                    outer = r if (r.start <= s.start and r.end >= s.end) else s
                    inner = s if outer is r else r
                    chosen = inner if SPECIFICITY.get(inner.type, 1) - SPECIFICITY.get(outer.type, 1) >= 4 else outer
                    if chosen is inner:
                        result[i] = Span(inner.start, inner.end, inner.type, max(r.score, s.score), inner.source)
                    else:
                        result[i] = Span(outer.start, outer.end, outer.type if outer.type == winner.type or SPECIFICITY.get(outer.type, 1) >= SPECIFICITY.get(inner.type, 1) else winner.type,
                                         max(r.score, s.score), f"{r.source}+{s.source}" if r.source != s.source else r.source)
                else:
                    loser = s if winner is r else r
                    if SPECIFICITY.get(winner.type, 1) - SPECIFICITY.get(loser.type, 1) >= 3:
                        # ex. « IBAN FR76… » vu comme organisation par spaCy : l'IBAN seul est gardé
                        result[i] = Span(winner.start, winner.end, winner.type, winner.score, winner.source)
                    else:
                        result[i] = Span(min(r.start, s.start), max(r.end, s.end), winner.type,
                                         max(r.score, s.score), f"{r.source}+{s.source}")
                merged = True
                break
            if not merged:
                result.append(s)
        # une fusion peut créer de nouveaux chevauchements : on repasse si besoin
        result.sort(key=lambda s: s.start)
        for a, b in zip(result, result[1:]):
            if b.start < a.end:
                return Detector._resolve_overlaps(result)
        return result


_detector: Detector | None = None
_lock = threading.Lock()


def get_detector() -> Detector:
    global _detector
    with _lock:
        if _detector is None:
            _detector = Detector()
        return _detector
