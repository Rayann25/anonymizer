"""Détecteurs Presidio adaptés au français et aux documents contractuels.

Presidio reste le socle : on lui ajoute des détecteurs pour les formats
français (téléphone, NIR, SIRET, dates en lettres, adresses) et pour les
références métier introduites par un intitulé (« contrat n° … »).
"""
from __future__ import annotations

import re

from presidio_analyzer import EntityRecognizer, Pattern, PatternRecognizer, RecognizerResult

LANG = "fr"

MONTHS = r"(?:janvier|f[ée]vrier|mars|avril|mai|juin|juillet|ao[uû]t|septembre|octobre|novembre|d[ée]cembre)"


# ---------------------------------------------------------------- validateurs
def _luhn_ok(digits: str) -> bool:
    total, alt = 0, False
    for ch in reversed(digits):
        d = int(ch)
        if alt:
            d *= 2
            if d > 9:
                d -= 9
        total += d
        alt = not alt
    return total % 10 == 0


class SiretRecognizer(PatternRecognizer):
    def __init__(self):
        super().__init__(
            supported_entity="SIRET",
            supported_language=LANG,
            patterns=[
                Pattern("siret", r"\b\d{3}\s?\d{3}\s?\d{3}\s?\d{5}\b", 0.4),
                Pattern("siren", r"\b\d{3}\s?\d{3}\s?\d{3}\b", 0.1),
            ],
            context=["siret", "siren", "rcs", "immatriculée", "société", "entreprise"],
        )

    def validate_result(self, pattern_text: str):
        digits = re.sub(r"\D", "", pattern_text)
        return _luhn_ok(digits) if len(digits) in (9, 14) else False


class NirRecognizer(PatternRecognizer):
    def __init__(self):
        super().__init__(
            supported_entity="NIR",
            supported_language=LANG,
            patterns=[Pattern(
                "nir",
                r"\b[12]\s?\d{2}\s?(?:0[1-9]|1[0-2]|[2-9]\d)\s?(?:2[AB]|\d{2})\s?\d{3}\s?\d{3}(?:\s?\d{2})?\b",
                0.5,
            )],
            context=["sécurité sociale", "securite sociale", "nir", "n° ss", "insee", "assuré social"],
        )

    def validate_result(self, pattern_text: str):
        raw = re.sub(r"\s", "", pattern_text).upper()
        if len(raw) == 15:
            body, key = raw[:13], raw[13:]
            body = body.replace("2A", "19").replace("2B", "18")
            try:
                if 97 - (int(body) % 97) == int(key):
                    return True  # clé valide : score maximal
            except ValueError:
                pass
        return None  # clé absente ou fausse : on garde le score du motif (priorité au rappel)


def build_pattern_recognizers() -> list[EntityRecognizer]:
    """Détecteurs à motif simple, avec mots-clés de contexte."""
    recs: list[EntityRecognizer] = [SiretRecognizer(), NirRecognizer()]

    recs.append(PatternRecognizer(
        supported_entity="TELEPHONE", supported_language=LANG,
        patterns=[Pattern("tel_fr", r"(?<![\w+])(?:(?:\+|00)33\s?\(?0?\)?\s?|0)[1-9](?:[\s.\-]?\d{2}){4}\b", 0.75)],
        context=["tel", "tél", "téléphone", "portable", "mobile", "joindre", "appeler"],
    ))
    recs.append(PatternRecognizer(
        supported_entity="DATE", supported_language=LANG,
        patterns=[
            Pattern("date_num", r"\b(?:0?[1-9]|[12]\d|3[01])[/.\-](?:0?[1-9]|1[0-2])[/.\-](?:19|20)?\d{2}\b", 0.6),
            Pattern("date_lettres", rf"(?i)\b(?:1er|0?[1-9]|[12]\d|3[01])\s+{MONTHS}\s+(?:19|20)\d{{2}}\b", 0.65),
            Pattern("mois_annee", rf"(?i)\b{MONTHS}\s+(?:19|20)\d{{2}}\b", 0.35),
        ],
    ))
    recs.append(PatternRecognizer(
        supported_entity="ADRESSE", supported_language=LANG,
        patterns=[Pattern(
            "adresse_fr",
            r"(?i)\b\d{1,4}(?:\s?(?:bis|ter))?,?\s+(?:rue|avenue|av\.|boulevard|bd|chemin|all[ée]e|impasse|place|route|quai|cours|r[ée]sidence|lotissement|square|esplanade)"
            r"(?:\s+(?:de|du|des|la|le|l'|d')?\s*[A-Za-zÀ-ÿ'\-]+){1,5}"
            r"(?:,?\s+\d{5}\s+[A-ZÀ-Ý][A-Za-zÀ-ÿ'\-]+(?:[ \-][A-ZÀ-Ý][A-Za-zÀ-ÿ'\-]+){0,2})?",
            0.7,
        )],
        context=["adresse", "domicile", "habite", "demeurant", "résidant"],
    ))
    recs.append(PatternRecognizer(
        supported_entity="PLAQUE", supported_language=LANG,
        patterns=[Pattern("siv", r"\b[A-HJ-NP-TV-Z]{2}[\- ]\d{3}[\- ][A-HJ-NP-TV-Z]{2}\b", 0.6)],
        context=["immatriculation", "véhicule", "voiture", "plaque"],
    ))
    recs.append(PatternRecognizer(
        supported_entity="BIC", supported_language=LANG,
        patterns=[Pattern("bic", r"\b[A-Z]{4}FR[A-Z0-9]{2}(?:[A-Z0-9]{3})?\b", 0.3)],
        context=["bic", "swift"],
    ))
    recs.append(PatternRecognizer(
        supported_entity="PIECE_IDENTITE", supported_language=LANG,
        patterns=[
            Pattern("passeport", r"\b\d{2}[A-Z]{2}\d{5}\b", 0.3),
            Pattern("cni", r"\b\d{12}\b", 0.05),
        ],
        context=["passeport", "carte d'identité", "cni", "pièce d'identité"],
    ))
    return recs


class KeyedReferenceRecognizer(EntityRecognizer):
    """Référence métier annoncée par un intitulé : « contrat n° CT-2024-8891 ».

    On renvoie la référence complète (jusqu'au prochain blanc), ce qui évite
    la fuite partielle observée dans l'ancien POC.
    """

    KEYS = [
        (r"contrat", "NUM_CONTRAT"),
        (r"avenant", "NUM_CONTRAT"),
        (r"police(?:\s+d'assurance)?", "NUM_POLICE"),
        (r"(?:client|adh[ée]rent|sociétaire|abonn[ée])", "NUM_CLIENT"),
        (r"(?:dossier|sinistre|r[ée]f[ée]rence|r[ée]f\.?|facture|ticket)", "NUM_DOSSIER"),
    ]

    def __init__(self):
        super().__init__(
            supported_entities=sorted({e for _, e in self.KEYS}),
            supported_language=LANG,
            name="KeyedReferenceRecognizer",
        )
        alts = "|".join(f"(?P<k{i}>{k})" for i, (k, _) in enumerate(self.KEYS))
        self.regex = re.compile(
            rf"(?i)\b(?:{alts})\s*(?:n[°o]\.?|num[ée]ro|num\.?|#)?\s*:?\s*"
            r"(?P<ref>(?=[A-Z0-9\-/._]*\d)[A-Z0-9][A-Z0-9\-/._]{3,}[A-Z0-9])",
        )

    def load(self):  # noqa: D401 - rien à charger
        return None

    def analyze(self, text, entities, nlp_artifacts=None):
        results = []
        for m in self.regex.finditer(text):
            idx = next(i for i in range(len(self.KEYS)) if m.group(f"k{i}"))
            entity = self.KEYS[idx][1]
            if entities and entity not in entities:
                continue
            ref = m.group("ref")
            # une simple année ou un montant n'est pas une référence
            if re.fullmatch(r"(19|20)\d{2}", ref) or re.fullmatch(r"\d{1,3}([.,]\d+)?", ref):
                continue
            results.append(RecognizerResult(entity, m.start("ref"), m.end("ref"), 0.85))
        return results


class StandaloneCodeRecognizer(EntityRecognizer):
    """Code alphanumérique à tirets sans intitulé (ex. « POL-77-112233 »).

    Score faible : il ne masque que si rien de plus précis ne couvre le même passage.
    """

    def __init__(self):
        super().__init__(supported_entities=["NUM_DOSSIER"], supported_language=LANG, name="StandaloneCodeRecognizer")
        self.regex = re.compile(r"\b(?=[A-Z0-9\-/]*\d)(?=[A-Z0-9\-/]*[A-Z])[A-Z]{1,6}[\-/]\d[A-Z0-9]*(?:[\-/][A-Z0-9]+)+\b")

    def load(self):
        return None

    def analyze(self, text, entities, nlp_artifacts=None):
        if entities and "NUM_DOSSIER" not in entities:
            return []
        return [RecognizerResult("NUM_DOSSIER", m.start(), m.end(), 0.5) for m in self.regex.finditer(text)]
