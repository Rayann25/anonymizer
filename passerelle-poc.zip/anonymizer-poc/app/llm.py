"""Appel du LLM selon la route décidée.

- externe : Mistral (API compatible OpenAI, hébergement UE), interchangeable
  via LLM_BASE_URL / LLM_MODEL ;
- local   : Ollama, pour le contenu très sensible mais nécessaire ;
- humain  : aucun LLM, message de passage à un conseiller.

Sans clé API, un LLM SIMULÉ répond, clairement étiqueté, pour que la démo
de bout en bout fonctionne hors ligne (dont la restitution des jetons).
"""
from __future__ import annotations

import re
import time

import httpx

from .catalog import BUSINESS_PROFILES
from .config import settings

TASKS = {
    "resume": "Fais un résumé clair et factuel de ce document en 5 à 8 lignes.",
    "obligations": "Liste les obligations de chaque partie, les échéances et les montants mentionnés.",
    "risques": "Repère les clauses inhabituelles ou défavorables pour le client et explique-les simplement.",
    "question": None,  # question libre
}

HUMAN_HANDOFF = ("Votre message va être transmis à un conseiller, qui reviendra vers vous rapidement. "
                 "Si vous êtes en danger ou en grande détresse, appelez le 3114 (prévention, 24 h/24) ou le 112.")
LOCAL_UNAVAILABLE = ("Votre demande contient des informations qui ne peuvent pas être traitées automatiquement. "
                     "Un conseiller va la reprendre.")


def system_prompt(profile: str) -> str:
    p = BUSINESS_PROFILES.get(profile, BUSINESS_PROFILES["gestion_contrats"])
    return (
        f"Tu es l'assistant du service « {p['label']} ». Ton rôle : {p['scope']}.\n"
        "Règles impératives :\n"
        "1. Le texte contient des jetons entre crochets comme [PERSONNE_1] ou [NUM_CONTRAT_2] qui remplacent des "
        "données personnelles. Recopie-les EXACTEMENT, sans les modifier ni les traduire, et ne cherche jamais à deviner leur valeur.\n"
        "2. Les mentions « [information personnelle retirée] » et les phrases du type « Le client signale… » remplacent "
        "volontairement des informations privées : n'y ajoute aucune supposition et ne demande pas de détails.\n"
        "3. Reste strictement dans ton rôle. Pour toute demande hors de ce périmètre, réponds poliment que tu ne peux "
        "aider que sur ce sujet.\n"
        "4. Réponds en français, de façon concise."
    )


async def complete(messages: list[dict], route: str) -> dict:
    t0 = time.perf_counter()
    if route == "humain":
        return {"text": HUMAN_HANDOFF, "provider": "aucun LLM (conseiller)", "simulated": False,
                "latency_ms": 0}
    try:
        if route == "local":
            async with httpx.AsyncClient() as c:
                r = await c.post(f"{settings.ollama_url}/api/chat", timeout=120,
                                 json={"model": settings.ollama_model, "stream": False, "messages": messages})
                r.raise_for_status()
                text = r.json()["message"]["content"]
            provider = f"LLM local ({settings.ollama_model})"
        elif settings.llm_api_key:
            async with httpx.AsyncClient() as c:
                r = await c.post(f"{settings.llm_base_url}/chat/completions", timeout=60,
                                 headers={"Authorization": f"Bearer {settings.llm_api_key}"},
                                 json={"model": settings.llm_model, "messages": messages, "temperature": 0.2})
                r.raise_for_status()
                text = r.json()["choices"][0]["message"]["content"]
            provider = f"LLM externe ({settings.llm_model})"
        else:
            text, provider = _simulate(messages), "LLM simulé (ajoutez MISTRAL_API_KEY)"
            return {"text": text, "provider": provider, "simulated": True,
                    "latency_ms": round((time.perf_counter() - t0) * 1000, 1)}
    except Exception as exc:
        if route == "local":
            return {"text": LOCAL_UNAVAILABLE, "provider": "LLM local injoignable : passage à un conseiller",
                    "simulated": False, "error": f"{type(exc).__name__}", "latency_ms": 0}
        return {"text": "", "provider": "LLM externe en erreur", "simulated": False,
                "error": f"{type(exc).__name__}: {exc}"[:300], "latency_ms": 0}
    return {"text": text, "provider": provider, "simulated": False,
            "latency_ms": round((time.perf_counter() - t0) * 1000, 1)}


def _simulate(messages: list[dict]) -> str:
    """Réponse déterministe qui réutilise les jetons, pour tester la restitution."""
    user = messages[-1]["content"]
    content = user.split("---", 1)[-1] if "---" in user else user
    tokens = list(dict.fromkeys(re.findall(r"\[[A-Z_]+_\d+\]", content)))
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+", content) if len(s.strip()) > 20][:4]
    who = next((t for t in tokens if t.startswith("[PERSONNE")), "le client")
    refs = ", ".join(t for t in tokens if not t.startswith("[PERSONNE"))[:200] or "aucune"
    if "Le client signale une difficulté financière" in content:
        body = f"Bonjour {who}, je comprends. Nous pouvons étudier ensemble un échéancier adapté pour régulariser la situation."
    elif "information personnelle retirée" in content:
        body = f"Bonjour {who}, merci pour votre message. Je peux vous aider sur votre demande concernant votre contrat."
    else:
        body = "Synthèse : " + " ".join(sentences)[:600] if sentences else f"Bonjour {who}, que puis-je faire pour vous ?"
    return f"{body}\n\nRéférences reprises : {refs}."
