"""API du microservice + interface web.

Lancement : uvicorn app.main:app --reload   puis http://localhost:8000
Documentation interactive : http://localhost:8000/docs
"""
from __future__ import annotations

import json
import logging
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import llm, pdf
from .catalog import (BUSINESS_PROFILES, ENTITIES, FAMILIES, SENSITIVE_CATEGORIES, STRATEGIES,
                      default_entities)
from .config import settings
from .detection.engine import get_detector
from .pipeline import protect
from .restore import restore, reverse_leak_check
from .sensitivity.classifiers import CLASSIFIERS, get_classifier
from .sensitivity.lexicon import INJECTION, OFF_TOPIC
from .vault import vault

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
STATIC = Path(__file__).parent / "static"

@asynccontextmanager
async def lifespan(_app):
    get_detector()  # charge Presidio et GLiNER une fois, au démarrage
    yield


app = FastAPI(
    lifespan=lifespan,
    title="Passerelle de confiance — microservice de pseudonymisation",
    description="Protège les données personnelles et sensibles avant tout appel à un LLM, puis restitue les réponses.",
    version="0.2.0",
)


# ------------------------------------------------------------------ modèles
class SensitiveOptions(BaseModel):
    enabled: bool = True
    business_context: str = "gestion_contrats"
    classifier: str | None = Field(None, description="lexical | jev | zeroshot | ollama")
    thresholds: dict | None = Field(None, description='ex. {"low": 0.35, "high": 0.65}')


class PseudonymizeIn(BaseModel):
    text: str
    session_id: str | None = None
    entities: list[str] | None = Field(None, description="Types à masquer ; absent = sélection par défaut")
    strategies: dict[str, str] | None = Field(None, description="Type -> pseudonyme | generalisation | suppression | conserver")
    sensitive: SensitiveOptions = SensitiveOptions()


class RestoreIn(BaseModel):
    session_id: str
    text: str


class ClassifyIn(BaseModel):
    text: str
    business_context: str = "gestion_contrats"
    classifier: str | None = None


class LlmIn(BaseModel):
    session_id: str
    task: str = "resume"
    question: str | None = None


class ChatIn(BaseModel):
    message: str
    session_id: str | None = None
    business_context: str = "gestion_contrats"
    classifier: str | None = None
    entities: list[str] | None = None


# ------------------------------------------------------------------ outils
def _session_or_404(sid: str):
    sess = vault.get(sid)
    if not sess:
        raise HTTPException(404, "Session inconnue ou expirée.")
    return sess


# ------------------------------------------------------------------ routes
@app.get("/api/health")
async def health():
    ollama = "injoignable"
    try:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"{settings.ollama_url}/api/tags", timeout=1.5)
            ollama = "joignable" if r.status_code == 200 else f"HTTP {r.status_code}"
    except Exception:
        pass
    return {
        "presidio": "actif (fr)",
        "gliner": get_detector().gliner_status,
        "llm_externe": f"{settings.llm_model} (clé présente)" if settings.llm_api_key else "simulé (pas de clé)",
        "jev": "clé présente" if settings.jev_api_key else "pas de clé",
        "ollama": ollama,
        "classifieur_par_defaut": settings.default_classifier,
    }


@app.get("/api/catalog")
def catalog():
    return {
        "families": FAMILIES, "entities": ENTITIES, "strategies": STRATEGIES,
        "sensitive_categories": SENSITIVE_CATEGORIES, "business_profiles": BUSINESS_PROFILES,
        "classifiers": {k: {"available": bool(c.available), "location": c.location} for k, c in CLASSIFIERS.items()},
        "tasks": {"resume": "Résumer", "obligations": "Obligations et échéances", "risques": "Clauses à risque",
                  "question": "Question libre"},
    }


@app.post("/api/pseudonymize")
async def pseudonymize(body: PseudonymizeIn):
    """Tâche 1 : choisir à l'appel quelles infos pseudonymiser et comment."""
    unknown = [e for e in (body.entities or []) if e not in ENTITIES]
    if unknown:
        raise HTTPException(422, f"Types inconnus : {unknown}. Voir /api/catalog.")
    sess = vault.get_or_create(body.session_id)
    res = await protect(body.text, sess, entities=body.entities, strategies=body.strategies,
                        sensitive=body.sensitive.model_dump())
    sess.protected_text = res["sent_text"]
    sess.last_result = res
    return res


@app.post("/api/documents")
async def documents(file: UploadFile = File(...), options: str = Form("{}")):
    """PDF natif ou scanné : extraction, protection, PDF masqué."""
    data = await file.read()
    if not data.startswith(b"%PDF"):
        raise HTTPException(415, "Le fichier n'est pas un PDF.")
    opts = json.loads(options or "{}")
    ext = pdf.extract(data)
    sess = vault.get_or_create(opts.get("session_id"))
    res = await protect(ext["text"], sess, entities=opts.get("entities"), strategies=opts.get("strategies"),
                        sensitive=opts.get("sensitive") or {})
    red = pdf.redact(data, ext["words"], res["entities"], mask_signatures=opts.get("mask_signatures", True))
    sess.protected_text = res["sent_text"]
    sess.last_result = res
    sess.document = {"name": file.filename, "pdf": red["pdf"]}
    res.update({
        "document": {"name": file.filename, "pages": ext["pages"], "redacted_words": red["redacted_words"],
                     "signature_zones": red["signature_zones"], "previews_redacted": red["previews"],
                     "previews_original": pdf.originals_preview(data),
                     "download": f"/api/documents/{sess.id}/masque.pdf"},
    })
    return res


@app.get("/api/documents/{session_id}/masque.pdf")
def download_redacted(session_id: str):
    sess = _session_or_404(session_id)
    if not sess.document:
        raise HTTPException(404, "Aucun document pour cette session.")
    name = Path(sess.document["name"] or "document.pdf").stem + "-masque.pdf"
    return Response(sess.document["pdf"], media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


@app.get("/api/mapping/{session_id}")
def mapping(session_id: str, x_mapping_token: str = Header(..., description="Jeton d'accès à la table")):
    """Tâche 2 : récupérer la table de correspondance (accès protégé et journalisé)."""
    if x_mapping_token != settings.mapping_api_token:
        raise HTTPException(403, "Jeton d'accès à la table invalide.")
    sess = _session_or_404(session_id)
    m = vault.audited_read(sess, who="api")
    return {"session_id": session_id, "expires_at": sess.expires,
            "entries": [{"token": t, "type": e["type"], "value": e["value"], "variants": e.get("variants", [])}
                        for t, e in m["entries"].items()],
            "access_log": sess.access_log}


@app.post("/api/restore")
def restore_endpoint(body: RestoreIn):
    sess = _session_or_404(body.session_id)
    res = restore(body.text, vault.read_mapping(sess))
    removed = set((sess.last_result or {}).get("removed_categories", []))
    res["leak_warnings"] = reverse_leak_check(body.text, removed)
    return res


@app.post("/api/classify")
async def classify(body: ClassifyIn):
    """Couche sens seule : catégories, intensité, nécessité, action proposée."""
    from .sensitivity.policy import ACTION_LABELS, decide
    from .sensitivity.segmenter import segment

    clf, notice = get_classifier(body.classifier)
    segs = segment(body.text)
    ass = await clf.classify([s.text for s in segs], body.business_context, [])
    out = []
    for s, a in zip(segs, ass):
        d = decide(a)
        out.append({"text": s.text, "assessment": a, "decision": d["action"],
                    "decision_label": ACTION_LABELS[d["action"]], "reason": d["reason"]})
    return {"classifier": clf.name, "notice": notice, "segments": out}


@app.post("/api/llm")
async def run_llm(body: LlmIn):
    """Envoie au LLM la version protégée du dernier texte de la session, puis restitue."""
    sess = _session_or_404(body.session_id)
    last = sess.last_result
    if not last:
        raise HTTPException(409, "Aucun texte protégé dans cette session.")
    if body.task == "question" and not body.question:
        raise HTTPException(422, "Question manquante.")
    instruction = body.question if body.task == "question" else llm.TASKS.get(body.task, llm.TASKS["resume"])
    question_note = None
    if body.task == "question":
        # la question elle-même peut contenir des données : elle passe par le même pipeline
        q = await protect(body.question, sess, sensitive={"enabled": False})
        instruction, question_note = q["sent_text"], q["entity_count"]
    messages = [{"role": "system", "content": llm.system_prompt(last["business_context"])},
                {"role": "user", "content": f"{instruction}\n\n---\n{last['sent_text']}"}]
    out = await llm.complete(messages, last["route"])
    restored = restore(out["text"], vault.read_mapping(sess)) if out["text"] else {"text": "", "restored": [], "unknown_tokens": []}
    return {"route": last["route"], "provider": out["provider"], "simulated": out.get("simulated"),
            "error": out.get("error"), "sent_to_llm": messages[-1]["content"], "raw_answer": out["text"],
            "restored_answer": restored["text"], "unknown_tokens": restored["unknown_tokens"],
            "leak_warnings": reverse_leak_check(out["text"], set(last.get("removed_categories", []))),
            "question_entities_masked": question_note, "latency_ms": out.get("latency_ms")}


@app.post("/api/chat")
async def chat(body: ChatIn):
    """Un tour de chatbot : garde-fous, protection, décision de route, LLM, restitution."""
    sess = vault.get_or_create(body.session_id)
    import re as _re

    guard = None
    if any(_re.search(p, body.message, _re.I) for p in INJECTION):
        guard = "injection"
    elif any(_re.search(p, body.message, _re.I) for p in OFF_TOPIC):
        guard = "hors_perimetre"

    history_protected = [t["sent"] for t in sess.history if t.get("sent")]
    res = await protect(body.message, sess, entities=body.entities or default_entities(),
                        sensitive={"business_context": body.business_context, "classifier": body.classifier},
                        history=history_protected)
    profile = BUSINESS_PROFILES.get(body.business_context, BUSINESS_PROFILES["gestion_contrats"])
    if guard:
        reply = {
            "injection": "Je ne peux pas modifier mes consignes ni révéler de données protégées. Comment puis-je vous aider sur votre dossier ?",
            "hors_perimetre": f"Je suis l'assistant du service « {profile['label']} » et je ne peux vous aider que sur ce sujet.",
        }[guard]
        out = {"text": reply, "provider": "garde-fou (aucun LLM appelé)", "simulated": False}
        route = "bloque"
    else:
        route = res["route"]
        messages = [{"role": "system", "content": llm.system_prompt(body.business_context)}]
        for t in sess.history[-6:]:
            if t.get("sent"):
                messages.append({"role": "user", "content": t["sent"]})
            if t.get("answer_raw"):
                messages.append({"role": "assistant", "content": t["answer_raw"]})
        messages.append({"role": "user", "content": res["sent_text"]})
        out = await llm.complete(messages, route)
    restored = restore(out["text"], vault.read_mapping(sess))
    leaks = reverse_leak_check(out["text"], set(res["removed_categories"]))
    sess.history.append({"sent": res["sent_text"] if route == "externe" else None, "answer_raw": out["text"] if route == "externe" else None})
    sess.last_result = res
    return {"session_id": sess.id, "reply": restored["text"], "route": route, "guard": guard,
            "provider": out["provider"], "simulated": out.get("simulated"), "error": out.get("error"),
            "protection": res, "raw_answer": out["text"], "unknown_tokens": restored["unknown_tokens"],
            "leak_warnings": leaks}


@app.delete("/api/session/{session_id}")
def delete_session(session_id: str):
    return {"deleted": vault.delete(session_id)}


@app.get("/api/eval/report")
def eval_report():
    p = Path(__file__).resolve().parent.parent / "eval" / "report.json"
    if not p.exists():
        raise HTTPException(404, "Banc de test pas encore lancé : python -m eval.run_eval")
    return json.loads(p.read_text())


SAMPLES = Path(__file__).resolve().parent.parent / "eval" / "data"


@app.get("/api/samples/{name}", include_in_schema=False)
def sample(name: str):
    allowed = {"contrat_fictif_natif.pdf", "contrat_fictif_scanne.pdf"}
    if name not in allowed or not (SAMPLES / name).exists():
        raise HTTPException(404, "Exemple introuvable : lancez python -m eval.make_fixtures")
    return FileResponse(SAMPLES / name, media_type="application/pdf")


# ------------------------------------------------------------------ interface
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(STATIC / "index.html")
