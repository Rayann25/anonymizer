"""Orchestration : détection -> pseudonymisation -> classification -> décision."""
from __future__ import annotations

import re
import time

from .catalog import BUSINESS_PROFILES, ENTITIES, REMOVED_MARKER, default_entities, default_strategies
from .detection.engine import get_detector
from .pseudonymizer import Pseudonymizer
from .sensitivity.classifiers import get_classifier
from .sensitivity.policy import ACTION_LABELS, Thresholds, decide, message_route, replacement_for
from .sensitivity.segmenter import is_only_tokens, segment
from .vault import Session, vault


TOKEN_LIKE = re.compile(rf"\[?\s*\b({'|'.join(sorted(ENTITIES, key=len, reverse=True))})[ _\-]?(\d+)\b\s*\]?", re.IGNORECASE)


def neutralize_token_injection(text: str) -> tuple[str, int]:
    """Un utilisateur qui tape « [PERSONNE_1] » ne doit jamais récupérer la valeur
    réelle à la restitution : on réécrit ces faux jetons sous une forme inerte."""
    count = 0

    def sub(m):
        nonlocal count
        count += 1
        # même longueur que l'original : les positions des mots (PDF) restent valides
        return m.group(0).lower().replace("[", "(").replace("]", ")").replace("_", "-")

    return TOKEN_LIKE.sub(sub, text), count


async def protect(text: str, sess: Session, *, entities: list[str] | None = None,
                  strategies: dict[str, str] | None = None, sensitive: dict | None = None,
                  history: list[str] | None = None) -> dict:
    t0 = time.perf_counter()
    entities = entities if entities is not None else default_entities()
    strat = default_strategies()
    strat.update(strategies or {})
    sensitive = {"enabled": True, "business_context": "gestion_contrats", "classifier": None, **(sensitive or {})}
    timings = {}
    text, injected = neutralize_token_injection(text)

    # 1. Détection locale (Presidio + GLiNER)
    spans = get_detector().detect(text, entities)
    timings["detection_ms"] = round((time.perf_counter() - t0) * 1000, 1)

    # 2. Pseudonymisation cohérente, table chiffrée dans le coffre
    ps = Pseudonymizer(vault.read_mapping(sess))
    protected, replacements = ps.apply(text, spans, strat)
    vault.write_mapping(sess, ps.mapping)

    # 3. Couche sens, sur le texte DÉJÀ pseudonymisé
    segments_out, notice, route = [], None, "externe"
    final_text = protected
    pieces = [{"text": protected, "action": None}]
    if sensitive.get("enabled", True):
        t1 = time.perf_counter()
        clf, notice = get_classifier(sensitive.get("classifier"))
        segs = [s for s in segment(protected) if not is_only_tokens(s.text)]
        assessments = await clf.classify([s.text for s in segs], sensitive["business_context"], history or [])
        th = Thresholds(**sensitive.get("thresholds", {})) if sensitive.get("thresholds") else Thresholds()
        pieces, cursor, out = [], 0, []
        for seg, a in zip(segs, assessments):
            d = decide(a, th) if not a.get("error") else {
                "action": "retirer", "categories": [], "doubt": True, "main": None,
                "reason": f"Classifieur en erreur ({a['error']}) : retrait par prudence."}
            repl = replacement_for(d)
            segments_out.append({
                "start": seg.start, "end": seg.end, "text": seg.text, "assessment": a,
                "decision": d["action"], "decision_label": ACTION_LABELS[d["action"]],
                "categories": d["categories"], "doubt": d["doubt"], "reason": d["reason"],
                "replacement": repl,
            })
            gap = protected[cursor:seg.start]
            # retraits consécutifs : une seule mention, pour ne pas révéler combien de phrases ont été retirées
            if (repl == REMOVED_MARKER and pieces and pieces[-1].get("text") == REMOVED_MARKER and not gap.strip()):
                pieces[-1]["original"] = (pieces[-1].get("original") or "") + gap + seg.text
                cursor = seg.end
                continue
            if gap:
                pieces.append({"text": gap, "action": None})
            shown = repl if repl is not None else seg.text
            pieces.append({"text": shown, "action": d["action"], "original": seg.text if repl else None})
            cursor = seg.end
        if cursor < len(protected):
            pieces.append({"text": protected[cursor:], "action": None})
        final_text = "".join(p["text"] for p in pieces)
        route = message_route([{"action": s["decision"]} for s in segments_out])
        timings["classification_ms"] = round((time.perf_counter() - t1) * 1000, 1)
        timings["classifier"] = clf.name
        timings["classifier_location"] = clf.location

    timings["total_ms"] = round((time.perf_counter() - t0) * 1000, 1)
    removed = sorted({c for s in segments_out if s["decision"] in ("retirer", "generaliser") for c in s["categories"]})
    return {
        "session_id": sess.id,
        "original_length": len(text),
        "entities": [{k: v for k, v in r.items() if k != "value"} | {"text": r["value"]} for r in replacements],
        "entity_count": len(replacements),
        "pseudonymized_text": protected,
        "segments": segments_out,
        "pieces": pieces,
        "sent_text": final_text,
        "route": route,
        "removed_categories": removed,
        "business_context": sensitive["business_context"],
        "business_label": BUSINESS_PROFILES.get(sensitive["business_context"], {}).get("label"),
        "notice": notice,
        "token_injection": injected,
        "original_text": text,
        "timings": timings,
    }
