"""Traitement des PDF : extraction (texte natif ou OCR), masquage réel du texte
et masquage visuel des zones de signature.

Le masquage utilise les « redactions » PyMuPDF : le texte sous le rectangle
est supprimé du fichier, pas seulement recouvert. Sur une page scannée, ce
sont les pixels de l'image qui sont effacés.
"""
from __future__ import annotations

import base64
import io
import re
from dataclasses import dataclass

import fitz  # PyMuPDF

from .config import settings

SIGNATURE_KEYS = re.compile(
    r"(?i)^(signature|sign[ée] (?:par|le)|lu et approuv[ée]|bon pour accord|le souscripteur|l'assur[ée]|le client|"
    r"pour (?:la soci[ée]t[ée]|l'assureur|le pr[êe]teur)|cachet)",
)


@dataclass
class Word:
    page: int
    rect: fitz.Rect
    text: str
    start: int  # position dans le texte complet
    end: int


def _ocr_page(page: fitz.Page, page_no: int, offset: int) -> tuple[list[Word], str]:
    import pytesseract
    from PIL import Image

    zoom = 300 / 72
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom))
    img = Image.open(io.BytesIO(pix.tobytes("png")))
    cfg = f'--tessdata-dir "{settings.tessdata}"'
    data = pytesseract.image_to_data(img, lang="fra", config=cfg, output_type=pytesseract.Output.DICT)
    words, parts, pos, last_line = [], [], offset, None
    for i, txt in enumerate(data["text"]):
        if not txt.strip() or float(data["conf"][i]) < 0:
            continue
        line_key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
        sep = "" if last_line is None else ("\n" if line_key != last_line else " ")
        parts.append(sep)
        pos += len(sep)
        x, y, w, h = (data[k][i] / zoom for k in ("left", "top", "width", "height"))
        words.append(Word(page_no, fitz.Rect(x, y, x + w, y + h), txt, pos, pos + len(txt)))
        parts.append(txt)
        pos += len(txt)
        last_line = line_key
    return words, "".join(parts)


def extract(pdf_bytes: bytes) -> dict:
    """Texte complet + position de chaque mot. OCR automatique si la page n'a pas de texte."""
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    all_words: list[Word] = []
    texts, pages_info, offset = [], [], 0
    for pno, page in enumerate(doc):
        native = page.get_text("words")  # x0,y0,x1,y1,word,block,line,wno
        if sum(len(w[4]) for w in native) >= 20:
            mode, parts, words, last = "texte natif", [], [], None
            pos = offset
            for x0, y0, x1, y1, txt, b, ln, _ in native:
                sep = "" if last is None else ("\n" if (b, ln) != last else " ")
                parts.append(sep)
                pos += len(sep)
                words.append(Word(pno, fitz.Rect(x0, y0, x1, y1), txt, pos, pos + len(txt)))
                parts.append(txt)
                pos += len(txt)
                last = (b, ln)
            page_text = "".join(parts)
        else:
            mode = "OCR"
            words, page_text = _ocr_page(page, pno, offset)
        all_words.extend(words)
        texts.append(page_text)
        pages_info.append({"page": pno + 1, "mode": mode, "words": len(words)})
        offset += len(page_text) + 2  # séparateur de page « \n\n »
    doc.close()
    return {"text": "\n\n".join(texts), "words": all_words, "pages": pages_info}


def _signature_bands(doc: fitz.Document, words: list[Word]) -> list[tuple[int, float, float, str]]:
    """Bandes verticales où chercher l'encre : sous chaque intitulé type
    « Signature », « Lu et approuvé », « Pour l'Assureur »."""
    bands = []
    by_page: dict[int, list[Word]] = {}
    for w in words:
        by_page.setdefault(w.page, []).append(w)
    for pno, ws in by_page.items():
        lines: dict[int, list[Word]] = {}
        for w in ws:
            lines.setdefault(round(w.rect.y0 / 4), []).append(w)
        for _, lw in sorted(lines.items()):
            lw.sort(key=lambda w: w.rect.x0)
            groups, cur = [], [lw[0]]
            for w in lw[1:]:
                if w.rect.x0 - cur[-1].rect.x1 > 40:
                    groups.append(cur)
                    cur = [w]
                else:
                    cur.append(w)
            groups.append(cur)
            for g in groups:
                label = " ".join(w.text for w in g)
                if SIGNATURE_KEYS.search(label):
                    y0 = min(w.rect.y0 for w in g) - 4
                    bands.append((pno, y0, min(doc[pno].rect.height, y0 + 130), label))
    # bandes qui se chevauchent sur une même page : fusionnées
    merged: list[tuple[int, float, float, str]] = []
    for b in sorted(bands):
        if merged and merged[-1][0] == b[0] and b[1] <= merged[-1][2]:
            m = merged[-1]
            merged[-1] = (m[0], m[1], max(m[2], b[2]), m[3] if b[3] in m[3] else f"{m[3]} / {b[3]}")
        else:
            merged.append(b)
    return merged


def _ink_blobs(page: fitz.Page, y0: float, y1: float, words: list[Word], cell: float = 5.0) -> list[fitz.Rect]:
    """Taches d'encre qui ne sont pas du texte reconnu : signatures, paraphes, tampons.
    Grille de cellules + composantes connexes : simple, sans modèle, à remplacer
    par un détecteur d'objets entraîné en phase 4."""
    from PIL import Image

    zoom = 2.0
    clip = fitz.Rect(0, y0, page.rect.width, y1)
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), clip=clip, colorspace=fitz.csGRAY)
    img = Image.frombytes("L", (pix.width, pix.height), pix.samples)
    cols, rows = int(clip.width / cell) + 1, int(clip.height / cell) + 1
    text_rects = [w.rect + (-2, -2, 2, 2) for w in words if w.rect.intersects(clip)]
    px = img.load()
    ink = set()
    for cy in range(rows):
        for cx in range(cols):
            r = fitz.Rect(cx * cell, y0 + cy * cell, (cx + 1) * cell, y0 + (cy + 1) * cell)
            if any(r.intersects(t) for t in text_rects):
                continue
            dark = total = 0
            for yy in range(int((r.y0 - y0) * zoom), min(pix.height, int((r.y1 - y0) * zoom)), 2):
                for xx in range(int(r.x0 * zoom), min(pix.width, int(r.x1 * zoom)), 2):
                    total += 1
                    dark += px[xx, yy] < 150
            if total and dark / total > 0.04:
                ink.add((cx, cy))
    blobs, seen = [], set()
    for start in ink:
        if start in seen:
            continue
        stack, comp = [start], []
        seen.add(start)
        while stack:
            c = stack.pop()
            comp.append(c)
            for dx in (-2, -1, 0, 1, 2):  # tolère les traits interrompus
                for dy in (-2, -1, 0, 1, 2):
                    n = (c[0] + dx, c[1] + dy)
                    if n in ink and n not in seen:
                        seen.add(n)
                        stack.append(n)
        if len(comp) < 6:  # grain de numérisation, poussière
            continue
        xs, ys = [c[0] for c in comp], [c[1] for c in comp]
        blobs.append(fitz.Rect(min(xs) * cell - 3, y0 + min(ys) * cell - 3,
                               (max(xs) + 1) * cell + 3, y0 + (max(ys) + 1) * cell + 3))
    return blobs


def redact(pdf_bytes: bytes, words: list[Word], entity_spans: list[dict], mask_signatures: bool = True) -> dict:
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    count, sig_count = 0, 0
    for span in entity_spans:
        hit = [w for w in words if w.end > span["start"] and w.start < span["end"]]
        for w in hit:
            page = doc[w.page]
            page.add_redact_annot(w.rect + (-1, -1, 1, 1), fill=(0.08, 0.13, 0.24))
            count += 1
    zones = []
    if mask_signatures:
        for pno, y0, y1, label in _signature_bands(doc, words):
            page_words = [w for w in words if w.page == pno]
            for rect in _ink_blobs(doc[pno], y0, y1, page_words):
                doc[pno].add_redact_annot(rect, fill=(0.08, 0.13, 0.24))
                zones.append((pno, rect, label))
                sig_count += 1
    for page in doc:
        page.apply_redactions(images=fitz.PDF_REDACT_IMAGE_PIXELS,
                              graphics=fitz.PDF_REDACT_LINE_ART_REMOVE_IF_TOUCHED)
    previews = []
    for page in doc:
        pix = page.get_pixmap(matrix=fitz.Matrix(1.3, 1.3))
        previews.append("data:image/png;base64," + base64.b64encode(pix.tobytes("png")).decode())
    out = doc.tobytes(garbage=4, deflate=True)
    doc.close()
    return {"pdf": out, "previews": previews, "redacted_words": count,
            "signature_zones": [{"page": p + 1, "near": lbl, "bbox": [round(v) for v in r]} for p, r, lbl in zones]}


def originals_preview(pdf_bytes: bytes) -> list[str]:
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    out = ["data:image/png;base64," + base64.b64encode(p.get_pixmap(matrix=fitz.Matrix(1.3, 1.3)).tobytes("png")).decode()
           for p in doc]
    doc.close()
    return out
