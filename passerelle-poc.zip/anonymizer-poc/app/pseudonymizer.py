"""Transformation des entités détectées : pseudonymes typés et cohérents,
généralisation, suppression. La table de correspondance est tenue par session."""
from __future__ import annotations

import re
import unicodedata
from datetime import date

from .detection.engine import TITLES, Span

MONTHS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août",
          "septembre", "octobre", "novembre", "décembre"]
MONTH_IDX = {unicodedata.normalize("NFD", m).encode("ascii", "ignore").decode(): i + 1 for i, m in enumerate(MONTHS)}

CITY_REGION = {
    "paris": "Île-de-France", "marseille": "Provence-Alpes-Côte d'Azur", "nice": "Provence-Alpes-Côte d'Azur",
    "toulon": "Provence-Alpes-Côte d'Azur", "aix-en-provence": "Provence-Alpes-Côte d'Azur",
    "lyon": "Auvergne-Rhône-Alpes", "grenoble": "Auvergne-Rhône-Alpes", "saint-etienne": "Auvergne-Rhône-Alpes",
    "toulouse": "Occitanie", "montpellier": "Occitanie", "nimes": "Occitanie", "bordeaux": "Nouvelle-Aquitaine",
    "limoges": "Nouvelle-Aquitaine", "nantes": "Pays de la Loire", "angers": "Pays de la Loire", "le mans": "Pays de la Loire",
    "rennes": "Bretagne", "brest": "Bretagne", "lille": "Hauts-de-France", "amiens": "Hauts-de-France",
    "strasbourg": "Grand Est", "reims": "Grand Est", "metz": "Grand Est", "nancy": "Grand Est",
    "rouen": "Normandie", "caen": "Normandie", "le havre": "Normandie", "dijon": "Bourgogne-Franche-Comté",
    "besancon": "Bourgogne-Franche-Comté", "orleans": "Centre-Val de Loire", "tours": "Centre-Val de Loire",
    "ajaccio": "Corse", "bastia": "Corse",
}


def _norm(value: str) -> str:
    value = TITLES.sub("", value.strip())
    value = unicodedata.normalize("NFD", value).encode("ascii", "ignore").decode()
    return re.sub(r"[\s\-.]+", " ", value.lower()).strip()


def _compact(value: str) -> str:
    return re.sub(r"[\s\-./]", "", value).upper()


def parse_fr_date(value: str) -> date | None:
    v = _norm(value)
    m = re.search(r"(\d{1,2})[/.\- ](\d{1,2})[/.\- ](\d{2,4})", v)
    if m:
        d, mo, y = (int(x) for x in m.groups())
    else:
        m = re.search(r"(1er|\d{1,2})\s+([a-z]+)\s+(\d{4})", v)
        if not m or m.group(2) not in MONTH_IDX:
            return None
        d = 1 if m.group(1) == "1er" else int(m.group(1))
        mo, y = MONTH_IDX[m.group(2)], int(m.group(3))
    if y < 100:
        y += 1900 if y > date.today().year % 100 else 2000
    try:
        return date(y, mo, d)
    except ValueError:
        return None


def generalize(etype: str, value: str, today: date | None = None) -> str | None:
    """Renvoie une valeur moins précise, ou None si on ne sait pas généraliser."""
    today = today or date.today()
    if etype == "DATE_NAISSANCE":
        d = parse_fr_date(value)
        if not d:
            return None
        age = today.year - d.year - ((today.month, today.day) < (d.month, d.day))
        low = age // 5 * 5
        return f"[âge : {low}-{low + 4} ans]"
    if etype == "DATE":
        d = parse_fr_date(value)
        return f"{MONTHS[d.month - 1]} {d.year}" if d else None
    if etype == "LIEU":
        region = CITY_REGION.get(_norm(value))
        return f"[ville en {region}]" if region else None
    if etype == "ADRESSE":
        m = re.search(r"\b(\d{2})\d{3}\b", value)
        return f"[adresse dans le département {m.group(1)}]" if m else None
    return None


class Pseudonymizer:
    """Pseudonymes cohérents : la même valeur (et ses variantes) garde le même jeton."""

    def __init__(self, mapping: dict | None = None):
        self.mapping = mapping or {"entries": {}, "counters": {}}

    def _find_existing(self, etype: str, value: str) -> str | None:
        key_n, key_c = _norm(value), _compact(value)
        for token, e in self.mapping["entries"].items():
            if e["type"] != etype:
                continue
            for v in [e["value"], *e.get("variants", [])]:
                if _norm(v) == key_n or (etype not in {"PERSONNE", "ORGANISATION", "LIEU"} and _compact(v) == key_c):
                    return token
            if etype == "PERSONNE":
                a, b = set(key_n.split()), set(_norm(e["value"]).split())
                # « Dupont » / « Jean Dupont » / « DUPONT Jean » : même personne
                if a and b and (a <= b or b <= a):
                    return token
        return None

    def token_for(self, etype: str, value: str) -> str:
        token = self._find_existing(etype, value)
        if token:
            e = self.mapping["entries"][token]
            if value != e["value"] and value not in e.setdefault("variants", []):
                e["variants"].append(value)
            return token
        n = self.mapping["counters"].get(etype, 0) + 1
        self.mapping["counters"][etype] = n
        token = f"[{etype}_{n}]"
        self.mapping["entries"][token] = {"type": etype, "value": value, "variants": []}
        return token

    def apply(self, text: str, spans: list[Span], strategies: dict[str, str]) -> tuple[str, list[dict]]:
        """Remplace les entités ; renvoie le texte protégé et la liste des remplacements
        (positions dans le texte d'origine ET dans le texte protégé)."""
        replacements = []
        for s in sorted(spans, key=lambda x: x.start):
            strategy = strategies.get(s.type, "pseudonyme")
            value = text[s.start:s.end]
            if strategy == "conserver":
                continue
            if strategy == "suppression":
                repl, reversible = "[INFORMATION RETIRÉE]", False
            elif strategy == "generalisation":
                g = generalize(s.type, value)
                if g is None:  # généralisation impossible : on retombe sur le pseudonyme
                    repl, reversible, strategy = self.token_for(s.type, value), True, "pseudonyme"
                else:
                    repl, reversible = g, False
            else:
                repl, reversible = self.token_for(s.type, value), True
            replacements.append({"start": s.start, "end": s.end, "type": s.type, "value": value,
                                 "replacement": repl, "strategy": strategy, "reversible": reversible,
                                 "score": s.score, "source": s.source})
        out, cursor = [], 0
        for r in replacements:
            out.append(text[cursor:r["start"]])
            r["out_start"] = sum(len(x) for x in out)
            out.append(r["replacement"])
            r["out_end"] = r["out_start"] + len(r["replacement"])
            cursor = r["end"]
        out.append(text[cursor:])
        return "".join(out), replacements
