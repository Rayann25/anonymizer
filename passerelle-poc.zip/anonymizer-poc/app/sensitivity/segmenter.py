"""Découpage d'un message en propositions, avec leurs positions.

« Je suis endetté depuis que ma femme m'a quitté » contient deux informations
sensibles distinctes : on coupe sur les connecteurs pour pouvoir traiter
chaque proposition séparément.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

SENTENCE_END = re.compile(r"(?<=[.!?…])\s+|\n+")
ABBREV = re.compile(r"(?:\b(?:M|Mme|Mlle|Me|Dr|Pr|St|Ste|av|bd|n°|réf|art|cf|etc|p|ex)\.|\b[A-Z]\.)$")
CONNECTORS = re.compile(
    r"\s+(?=(?:depuis que|parce que|puisque|alors que|car|mais|et que|et puis|sauf que|du coup)\b)|,\s+(?=et\b)"
    r"|\s+(?=et (?:j'|je |il |elle |on |nous |depuis ))"
    # « …m'a quitté, je peux payer en 3 fois ? » : la demande est une proposition à part
    r"|,\s+(?=(?:je |j'|est-ce |pouvez|puis-je|peut-on|pourriez|comment |quand |combien |que faire|quelle?s? ))",
    re.IGNORECASE,
)
TOKEN_ONLY = re.compile(r"^\W*(?:\[[A-Z_]+_\d+\]\W*)+$")


@dataclass
class Segment:
    start: int
    end: int
    text: str


def segment(text: str, min_len: int = 12) -> list[Segment]:
    pieces: list[tuple[int, int]] = []
    pos = 0
    for sm in SENTENCE_END.finditer(text + "\n"):
        # « M. Dupont », « n°. » : pas une fin de phrase
        if sm.start() < len(text) and ABBREV.search(text[max(0, sm.start() - 6):sm.start()]) and "\n" not in sm.group(0):
            continue
        s_start, s_end = pos, sm.start()
        pos = sm.end()
        if s_end <= s_start:
            continue
        sub_start = s_start
        sentence = text[s_start:s_end]
        for cm in CONNECTORS.finditer(sentence):
            cut = s_start + cm.start()
            if cut - sub_start >= min_len:
                pieces.append((sub_start, cut))
                sub_start = s_start + cm.end()
        pieces.append((sub_start, s_end))

    segments: list[Segment] = []
    for a, b in pieces:
        while a < b and text[a].isspace():
            a += 1
        while b > a and text[b - 1].isspace():
            b -= 1
        if b <= a:
            continue
        # morceau trop court (« Merci. ») : rattaché au précédent
        if segments and (b - a < min_len) and text[segments[-1].end:a].strip() == "":
            prev = segments[-1]
            segments[-1] = Segment(prev.start, b, text[prev.start:b])
            continue
        segments.append(Segment(a, b, text[a:b]))
    return segments


def is_only_tokens(seg_text: str) -> bool:
    return bool(TOKEN_ONLY.match(seg_text))
