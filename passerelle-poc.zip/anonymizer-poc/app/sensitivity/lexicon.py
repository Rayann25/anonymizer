"""Lexique du classifieur local de référence (baseline).

Chaque motif a un poids : ~0.9 pour une mention explicite (« dépression »),
~0.6-0.75 pour une formulation implicite (« je tiens pas jusqu'au 15 »).
C'est volontairement simple : il sert d'étalon face à Jev et aux modèles
zero-shot sur le banc de test.
"""

LEXICON: dict[str, list[tuple[str, float]]] = {
    "SANTE": [
        (r"\bd[ée]pression\b|\bd[ée]prim[ée]e?\b|\bburn[\s-]?out\b", 0.95),
        (r"\bcancer|chimio|tumeur|diab[èe]te|s[ée]ropositi|vih\b|sida\b|alzheimer|parkinson|scl[ée]rose", 0.95),
        (r"\bhospitalis[ée]e?|\bh[ôo]pital\b|\bop[ée]r[ée]e?\b|\bop[ée]ration\b|\burgences\b", 0.85),
        (r"\barr[êe]t (?:de travail|maladie)\b|\ben arr[êe]t\b|\bmi-temps th[ée]rapeutique", 0.85),
        (r"\bmaladie\b|\bmalade\b|\btraitement\b|\bm[ée]dicament|\bth[ée]rapie|\bpsychiatr|\bpsychologue|\bm[ée]decin\b", 0.75),
        (r"\benceinte\b|\bgrossesse\b|\bfausse couche|\bhandicap|\binvalidit[ée]|\bmdph\b|\baah\b", 0.85),
        (r"\banxi[ée]t[ée]|\bcrises? d'angoisse|\bje dors (?:plus|pas)\b|\binsomnie", 0.7),
        (r"\balcool(?:ique|isme)|\baddiction|\bd[ée]pendance|\bsevrage", 0.85),
    ],
    "FINANCES": [
        (r"\bendett[ée]e?s?\b|\bdettes?\b|\bsurendett|\bbanque de france\b|\bfich[ée]e? (?:fcc|ficp|banque)", 0.9),
        (r"\bd[ée]couvert\b|\bimpay[ée]s?\b|\bhuissier|\bsaisie\b|\bcontentieux|\brelances?\b", 0.8),
        (r"\bch[ôo]mage\b|\bp[ôo]le emploi\b|\bfrance travail\b|\brsa\b|\bminima sociaux|\blicenci[ée]", 0.8),
        (r"\bfins? de mois|\bj(?:e |')?tiens? pas jusqu|\bboucler (?:le|mes) (?:mois|fins)|\bplus un (?:sou|centime|rond)", 0.75),
        (r"\bpas les moyens|\bplus les moyens|\bgal[èe]re (?:financi|pour payer)|\bdifficult[ée]s? (?:financi|à payer)", 0.8),
        (r"\bmon salaire\b|\bje gagne\b|\bmes revenus\b|\bje touche\b", 0.6),
    ],
    "FAMILLE": [
        (r"\bm'a quitt[ée]e?\b|\bdivorc|\bs[ée]par[ée]e?s?\b|\bs[ée]paration\b|\brupture\b", 0.9),
        (r"\bveu(?:f|ve)\b|\bd[ée]c[èe]s\b|\bd[ée]c[ée]d[ée]e?\b|\bdeuil\b|\bdisparu\b|\bdisparition de m", 0.9),
        (r"\bgarde (?:des|de mes) enfants|\bpension alimentaire|\bgarde altern[ée]e|\bjuge aux affaires familiales|\bjaf\b", 0.9),
        (r"\bma (?:femme|compagne|conjointe|copine|m[èe]re|fille)\b|\bmon (?:mari|compagnon|conjoint|copain|p[èe]re|fils|ex)\b|\bmes enfants\b", 0.55),
        (r"\bje vis seule?\b|\bm[èe]re c[ée]libataire|\bp[èe]re c[ée]libataire|\bfamille monoparentale", 0.7),
        (r"\bdepuis (?:le|mon|son) d[ée]part\b|\belle est partie\b|\bil est parti\b", 0.65),
    ],
    "JUDICIAIRE": [
        (r"\bcondamn[ée]e?\b|\bprison\b|\bincarc[ée]r|\bcasier judiciaire|\bgarde [àa] vue\b|\bsursis\b", 0.95),
        (r"\bporter plainte|\bport[ée] plainte|\bproc[èe]s\b|\btribunal\b|\bavocat\b|\bmis(?:e)? en examen", 0.8),
    ],
    "ART9": [
        (r"\bmusulman|\bjuif|\bjuive|\bchr[ée]tien|\bcatholique|\bprotestant|\bbouddhiste|\bramadan\b|\bmosqu[ée]e|\bsynagogue|\b[ée]glise\b", 0.85),
        (r"\bhomosexuel|\bgay\b|\blesbienne|\bbisexuel|\btrans(?:genre)?\b|\bmon copain et moi\b", 0.85),
        (r"\bsyndiqu[ée]|\bsyndicat\b|\bcgt\b|\bcfdt\b|\bd[ée]l[ée]gu[ée] syndical", 0.85),
        (r"\bje vote\b|\bmilitant|\bparti (?:politique|socialiste|communiste)|\brassemblement national|\b(?:lfi|lr|rn)\b", 0.8),
        (r"\bd'origine (?:alg[ée]rienne|marocaine|africaine|tunisienne|asiatique|roumaine)|\bimmigr[ée]", 0.8),
    ],
}

# Détresse : le message doit être traité par un humain, pas par un LLM.
DISTRESS = [
    (r"\bj'en peux plus\b|\bje n'en peux plus\b|\bje craque\b|\bau bout du rouleau", 0.75),
    (r"\ben finir\b|\bplus envie de vivre\b|\bme foutre en l'air\b|\bdispara[iî]tre pour de bon", 0.95),
]

# Tentatives de détournement du chatbot
INJECTION = [
    r"\bignore (?:tes|les|toutes les) (?:instructions|consignes|r[èe]gles)",
    r"\boublie (?:tes|les) (?:instructions|consignes)",
    r"\btu es (?:maintenant|d[ée]sormais) ",
    r"\b(?:prompt|message) syst[èe]me\b|\bsystem prompt\b|\bjailbreak\b|\bmode d[ée]veloppeur\b",
    r"\br[ée]v[èe]le (?:tes|les) (?:instructions|jetons|donn[ée]es)",
    r"\bquelle est la vraie valeur de \[",
]

# Demandes clairement hors du rôle d'un assistant client
OFF_TOPIC = [
    r"\b(?:[ée]cris|r[ée]dige)[- ]moi (?:un|une) (?:po[èe]me|chanson|histoire|dissertation)",
    r"\brecette\b|\bblague\b|\bm[ée]t[ée]o\b|\bhoroscope\b",
    r"\b(?:code|script) (?:python|javascript|java)\b|\bfais mes devoirs\b",
    r"\bqui va gagner\b|\bpour qui voter\b",
]
