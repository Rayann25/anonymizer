"""Classifieurs de sensibilité interchangeables.

Tous reçoivent des propositions DÉJÀ pseudonymisées et renvoient la même
structure, pour pouvoir être comparés sur le banc de test :

    {"categories": {"SANTE": 0.9, ...}, "intensity": 0..3, "necessary": 0..1,
     "distress": 0..1, "source": "...", "latency_ms": ..., "error": None}
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import time

import httpx

from ..catalog import BUSINESS_PROFILES, SENSITIVE_CATEGORIES
from ..config import settings
from .lexicon import DISTRESS, LEXICON

log = logging.getLogger(__name__)
CATS = list(SENSITIVE_CATEGORIES)
VERY = {c for c, v in SENSITIVE_CATEGORIES.items() if v["level"] == "tres_sensible"}

CATEGORY_QUESTIONS = {
    "SANTE": "Le passage évoque-t-il la santé physique ou mentale d'une personne (maladie, traitement, arrêt, grossesse, handicap, souffrance psychique) ?",
    "FINANCES": "Le passage évoque-t-il la situation financière personnelle de quelqu'un (dettes, impayés, revenus, chômage, difficulté à payer) ?",
    "FAMILLE": "Le passage évoque-t-il la vie familiale ou conjugale de quelqu'un (séparation, divorce, deuil, enfants, conjoint) ?",
    "JUDICIAIRE": "Le passage évoque-t-il une situation judiciaire (condamnation, plainte, procès, garde à vue) ?",
    "ART9": "Le passage révèle-t-il la religion, les opinions politiques, l'appartenance syndicale, l'orientation sexuelle ou l'origine de quelqu'un ?",
}
NOUL_CRITERIA = {"true": "Oui, même de façon implicite ou indirecte", "false": "Non, le passage n'en parle pas"}


def _empty(source: str) -> dict:
    return {"categories": {c: 0.0 for c in CATS}, "intensity": 0.0, "necessary": 0.0,
            "distress": 0.0, "source": source, "latency_ms": 0, "error": None}


def _derive_intensity(cats: dict[str, float]) -> float:
    return round(max([0.0] + [p * (3 if c in VERY else 2) for c, p in cats.items()]), 2)


class LexicalClassifier:
    """Référence locale, sans modèle : lexique pondéré + règle métier."""

    name = "lexical"
    available = True
    location = "local"

    async def classify(self, segments: list[str], profile: str, history: list[str] | None = None) -> list[dict]:
        needed = set(BUSINESS_PROFILES.get(profile, {}).get("needed", []))
        out = []
        for seg in segments:
            t0 = time.perf_counter()
            res = _empty(self.name)
            for cat, patterns in LEXICON.items():
                res["categories"][cat] = max([0.0] + [w for p, w in patterns if re.search(p, seg, re.IGNORECASE)])
            res["distress"] = max([0.0] + [w for p, w in DISTRESS if re.search(p, seg, re.IGNORECASE)])
            res["intensity"] = _derive_intensity(res["categories"])
            hot = [c for c, p in res["categories"].items() if p >= 0.35]
            res["necessary"] = max([0.0] + [0.9 if c in needed else 0.1 for c in hot])
            res["latency_ms"] = round((time.perf_counter() - t0) * 1000, 2)
            out.append(res)
        return out


class JevClassifier:
    """Jev (TypeSafe) : une passe par proposition, toutes les questions en parallèle.

    Hébergé aux États-Unis : il ne reçoit QUE du texte déjà pseudonymisé.
    """

    name = "jev"
    location = "API TypeSafe (États-Unis)"

    @property
    def available(self) -> bool:
        return bool(settings.jev_api_key)

    def _questions(self, scope: str) -> dict:
        q = {f"cat_{c}": {"type": "noul", "instructions": txt, "criteria": NOUL_CRITERIA}
             for c, txt in CATEGORY_QUESTIONS.items()}
        q["intensite"] = {"type": "score", "instructions": "À quel point ce passage est-il intime pour la personne qui l'écrit ?",
                          "criteria": ["Rien de personnel", "Un peu personnel", "Personnel", "Très intime"]}
        q["necessaire"] = {"type": "noul",
                           "instructions": f"Cette information est-elle nécessaire pour que l'assistant puisse traiter la demande, sachant que son rôle est de {scope} ?",
                           "criteria": {"true": "Sans elle, l'assistant ne peut pas bien traiter la demande",
                                        "false": "L'assistant peut traiter la demande sans elle"}}
        q["detresse"] = {"type": "noul", "instructions": "La personne exprime-t-elle une détresse grave ou un danger pour elle-même ?",
                         "criteria": {"true": "Oui, détresse grave ou danger", "false": "Non"}}
        return q

    async def _one(self, client: httpx.AsyncClient, seg: str, scope: str, history: list[str]) -> dict:
        res = _empty(self.name)
        t0 = time.perf_counter()
        body = {
            "model": settings.jev_model,
            "state": {"role_de_l_assistant": scope, "messages_precedents": history[-3:], "passage_a_evaluer": seg},
            "questions": self._questions(scope),
        }
        try:
            r = await client.post(settings.jev_url, json=body,
                                  headers={"Authorization": f"Bearer {settings.jev_api_key}"}, timeout=15)
            r.raise_for_status()
            ans = r.json()["answers"]
            for c in CATS:
                res["categories"][c] = round(float(ans[f"cat_{c}"]["noul"]), 3)
            res["intensity"] = round(float(ans["intensite"]["score"]), 2)
            res["necessary"] = round(float(ans["necessaire"]["noul"]), 3)
            res["distress"] = round(float(ans["detresse"]["noul"]), 3)
        except Exception as exc:
            res["error"] = f"{type(exc).__name__}: {exc}"[:200]
        res["latency_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        return res

    async def classify(self, segments, profile, history=None):
        scope = BUSINESS_PROFILES.get(profile, {}).get("scope", "aider le client")
        async with httpx.AsyncClient() as client:
            return await asyncio.gather(*[self._one(client, s, scope, history or []) for s in segments])


class ZeroShotClassifier:
    """Modèle NLI multilingue en local (mDeBERTa-XNLI), sans entraînement."""

    name = "zeroshot"
    location = "local"
    model_id = "MoritzLaurer/mDeBERTa-v3-base-mnli-xnli"
    HYPOTHESES = {
        "SANTE": "Ce texte parle de santé, de maladie ou de souffrance psychique.",
        "FINANCES": "Ce texte parle de dettes, d'argent qui manque ou de difficultés financières.",
        "FAMILLE": "Ce texte parle de séparation, de deuil ou de la famille de la personne.",
        "JUDICIAIRE": "Ce texte parle de justice, de police ou de condamnation.",
        "ART9": "Ce texte parle de religion, de politique, de syndicat ou d'orientation sexuelle.",
    }

    def __init__(self):
        self._pipe = None
        self._status = "non chargé"

    @property
    def available(self) -> bool:
        try:
            import transformers  # noqa: F401
            return True
        except ImportError:
            return False

    def _load(self):
        if self._pipe is None:
            from transformers import pipeline
            self._pipe = pipeline("zero-shot-classification", model=self.model_id, device=-1)
        return self._pipe

    async def classify(self, segments, profile, history=None):
        needed = set(BUSINESS_PROFILES.get(profile, {}).get("needed", []))

        def run():
            pipe = self._load()
            out = []
            labels = list(self.HYPOTHESES.values())
            for seg in segments:
                t0 = time.perf_counter()
                res = _empty(self.name)
                r = pipe(seg, candidate_labels=labels, hypothesis_template="{}", multi_label=True)
                by_label = dict(zip(r["labels"], r["scores"]))
                for c, h in self.HYPOTHESES.items():
                    res["categories"][c] = round(float(by_label[h]), 3)
                res["intensity"] = _derive_intensity(res["categories"])
                hot = [c for c, p in res["categories"].items() if p >= 0.35]
                res["necessary"] = max([0.0] + [0.9 if c in needed else 0.1 for c in hot])
                res["latency_ms"] = round((time.perf_counter() - t0) * 1000, 1)
                out.append(res)
            return out

        try:
            return await asyncio.to_thread(run)
        except Exception as exc:
            errs = []
            for _ in segments:
                e = _empty(self.name)
                e["error"] = f"{type(exc).__name__}: {exc}"[:200]
                errs.append(e)
            return errs


class OllamaClassifier:
    """Petit LLM local (Ollama) avec réponse JSON structurée."""

    name = "ollama"
    location = "local (Ollama)"
    available = True  # vérifié à l'appel

    PROMPT = (
        "Tu es un filtre de confidentialité. Rôle de l'assistant : {scope}.\n"
        "Pour le passage ci-dessous, réponds UNIQUEMENT en JSON avec des probabilités entre 0 et 1 :\n"
        '{{"SANTE":p,"FINANCES":p,"FAMILLE":p,"JUDICIAIRE":p,"ART9":p,"intensite":0-3,"necessaire":p,"detresse":p}}\n'
        "necessaire = l'information est-elle indispensable pour traiter la demande.\n"
        "Messages précédents : {history}\nPassage : {seg}"
    )

    async def classify(self, segments, profile, history=None):
        scope = BUSINESS_PROFILES.get(profile, {}).get("scope", "aider le client")
        out = []
        async with httpx.AsyncClient() as client:
            for seg in segments:
                res = _empty(self.name)
                t0 = time.perf_counter()
                try:
                    r = await client.post(f"{settings.ollama_url}/api/chat", timeout=60, json={
                        "model": settings.ollama_model, "stream": False, "format": "json",
                        "messages": [{"role": "user", "content": self.PROMPT.format(scope=scope, history=(history or [])[-3:], seg=seg)}],
                    })
                    r.raise_for_status()
                    data = json.loads(r.json()["message"]["content"])
                    for c in CATS:
                        res["categories"][c] = float(data.get(c, 0))
                    res["intensity"] = float(data.get("intensite", _derive_intensity(res["categories"])))
                    res["necessary"] = float(data.get("necessaire", 0))
                    res["distress"] = float(data.get("detresse", 0))
                except Exception as exc:
                    res["error"] = f"{type(exc).__name__}: {exc}"[:200]
                res["latency_ms"] = round((time.perf_counter() - t0) * 1000, 1)
                out.append(res)
        return out


class HybridClassifier:
    """Lexique (fiable sur l'explicite) + zero-shot recalibré (meilleur sur l'implicite).

    Le zero-shot donne des probabilités trop hautes : au seuil par défaut il
    signale 64 % des phrases neutres sur le banc de test. On ne retient son avis
    qu'au-delà de 0,95, ce qui ramène le sur-masquage à 16 %.
    """

    name = "hybride"
    location = "local"
    ZS_CUT = 0.95

    def __init__(self, lexical, zeroshot):
        self.lexical, self.zeroshot = lexical, zeroshot

    @property
    def available(self) -> bool:
        return self.zeroshot.available

    @classmethod
    def combine(cls, lx: dict, zs: dict, needed: set[str]) -> dict:
        res = _empty(cls.name)
        for c in CATS:
            z = zs["categories"].get(c, 0.0)
            z = 0.66 + (z - cls.ZS_CUT) / (1 - cls.ZS_CUT) * 0.3 if z >= cls.ZS_CUT else 0.0
            res["categories"][c] = round(max(lx["categories"].get(c, 0.0), z), 3)
        res["distress"] = lx["distress"]
        res["intensity"] = _derive_intensity(res["categories"])
        hot = [c for c, p in res["categories"].items() if p >= 0.35]
        res["necessary"] = max([0.0] + [0.9 if c in needed else 0.1 for c in hot])
        res["latency_ms"] = round(lx["latency_ms"] + zs["latency_ms"], 1)
        res["error"] = zs.get("error")
        return res

    async def classify(self, segments, profile, history=None):
        needed = set(BUSINESS_PROFILES.get(profile, {}).get("needed", []))
        lx = await self.lexical.classify(segments, profile, history)
        zs = await self.zeroshot.classify(segments, profile, history)
        out = []
        for a, b in zip(lx, zs):
            out.append(a if b.get("error") else self.combine(a, b, needed))
        return out


_lexical, _zeroshot = LexicalClassifier(), ZeroShotClassifier()

CLASSIFIERS = {
    "lexical": _lexical,
    "hybride": HybridClassifier(_lexical, _zeroshot),
    "jev": JevClassifier(),
    "zeroshot": _zeroshot,
    "ollama": OllamaClassifier(),
}


def get_classifier(name: str | None):
    clf = CLASSIFIERS.get(name or settings.default_classifier, CLASSIFIERS["lexical"])
    if not clf.available:
        return CLASSIFIERS["lexical"], f"« {name} » indisponible (clé ou dépendance manquante) : classifieur lexical utilisé."
    return clf, None
