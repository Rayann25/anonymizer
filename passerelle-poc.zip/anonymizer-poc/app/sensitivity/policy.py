"""Règle de décision : sensibilité × nécessité à la tâche.

|                      | nécessaire          | pas nécessaire     |
|----------------------|---------------------|--------------------|
| peu sensible         | garder              | garder             |
| sensible             | généraliser         | retirer            |
| très sensible        | bloquer (local)     | retirer            |
| détresse             | humain              | humain             |
| doute (zone grise)   | action la plus prudente                  |
"""
from __future__ import annotations

from dataclasses import dataclass

from ..catalog import REMOVED_MARKER, SENSITIVE_CATEGORIES, TEMPLATES

VERY = {c for c, v in SENSITIVE_CATEGORIES.items() if v["level"] == "tres_sensible"}

ACTION_LABELS = {
    "garder": "Gardé tel quel",
    "generaliser": "Généralisé",
    "retirer": "Retiré",
    "bloquer": "Bloqué pour le LLM externe",
    "humain": "Transmis à un conseiller",
}


@dataclass
class Thresholds:
    low: float = 0.35   # en dessous : pas sensible
    high: float = 0.65  # au-dessus : sensible certain ; entre les deux : doute


def decide(assessment: dict, th: Thresholds | None = None) -> dict:
    th = th or Thresholds()
    cats = assessment["categories"]
    hot = {c: p for c, p in cats.items() if p >= th.low}
    if assessment.get("distress", 0) >= th.high:
        return {"action": "humain", "categories": sorted(hot), "doubt": False,
                "reason": "Détresse exprimée : réponse par un humain, pas par un LLM."}
    if not hot:
        return {"action": "garder", "categories": [], "doubt": False, "reason": "Aucune information sensible détectée."}

    main = max(hot, key=hot.get)
    doubt = hot[main] < th.high
    nec = assessment.get("necessary", 0.0)
    necessary = nec >= th.high
    nec_doubt = th.low <= nec < th.high
    very = any(c in VERY for c in hot)

    if very:
        if necessary:
            action, reason = "bloquer", "Très sensible et nécessaire : traitement par un LLM local ou un humain."
        else:
            action, reason = "retirer", "Très sensible et pas nécessaire à la demande : retiré."
            if nec_doubt:
                reason += " (nécessité incertaine : retrait par prudence)"
    else:
        if necessary:
            action, reason = "generaliser", "Sensible mais utile à la demande : remplacé par une formulation générale."
        elif nec_doubt:
            action, reason = "generaliser", "Sensible, nécessité incertaine : généralisé par prudence."
        else:
            action, reason = "retirer", "Sensible et pas nécessaire à la demande : retiré."
    if doubt:
        reason += " Détection dans la zone de doute : action prudente appliquée."
    return {"action": action, "categories": sorted(hot, key=hot.get, reverse=True), "doubt": doubt,
            "main": main, "reason": reason}


def replacement_for(decision: dict) -> str | None:
    """Texte qui remplace la proposition ; None = la proposition reste."""
    a = decision["action"]
    if a in ("garder", "bloquer", "humain"):
        return None  # bloquer / humain : le message entier ne part pas, rien à réécrire
    if a == "generaliser":
        return TEMPLATES[decision["main"]]
    return REMOVED_MARKER


def message_route(decisions: list[dict]) -> str:
    actions = {d["action"] for d in decisions}
    if "humain" in actions:
        return "humain"
    if "bloquer" in actions:
        return "local"
    return "externe"
