"""Restitution : réinjecte les vraies valeurs dans la réponse du LLM.

Le LLM ne recopie pas toujours les jetons à l'identique (« [personne_1] »,
« PERSONNE 1 », « M. [PERSONNE_1] »). La restitution tolère ces variantes,
signale les jetons inconnus (inventés par le LLM) et repère les réponses qui
réintroduisent une information sensible retirée.
"""
from __future__ import annotations

import re

from .catalog import ENTITIES
from .sensitivity.lexicon import LEXICON

TYPES = "|".join(sorted(ENTITIES, key=len, reverse=True))
# forme avec crochets, tolérante à la casse et aux espaces : [personne_1], [ PERSONNE 1 ]
BRACKET_RE = re.compile(rf"\[\s*(?i:({TYPES}))[ _\-]?(\d+)\s*\]")
# forme sans crochets : seulement en majuscules (PERSONNE_1, PERSONNE 1) pour éviter les faux positifs
BARE_RE = re.compile(rf"(?<!\[)\b({TYPES})[ _](\d+)\b(?!\])")


def restore(text: str, mapping: dict) -> dict:
    entries = mapping.get("entries", {})
    unknown, restored_tokens = [], []

    def sub(m: re.Match) -> str:
        token = f"[{m.group(1).upper()}_{int(m.group(2))}]"
        e = entries.get(token)
        if e is None:
            unknown.append(m.group(0).strip())
            return m.group(0)
        restored_tokens.append(token)
        return e["value"]

    out = BARE_RE.sub(sub, BRACKET_RE.sub(sub, text))
    return {"text": out, "restored": sorted(set(restored_tokens)), "unknown_tokens": sorted(set(unknown))}


def reverse_leak_check(answer: str, removed_categories: set[str]) -> list[dict]:
    """La réponse parle-t-elle d'une catégorie qu'on avait retirée du message ?"""
    warnings = []
    for cat in removed_categories:
        for pattern, _w in LEXICON.get(cat, []):
            m = re.search(pattern, answer, re.IGNORECASE)
            if m:
                warnings.append({"category": cat, "excerpt": m.group(0)})
                break
    return warnings
