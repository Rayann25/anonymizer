"""Coffre des sessions : table de correspondance chiffrée (AES-256-GCM).

La table n'existe en clair que le temps d'un traitement. Elle est stockée
chiffrée, a une durée de vie limitée, et chaque lecture via l'API est journalisée.
"""
from __future__ import annotations

import json
import logging
import os
import secrets
import threading
import time
from dataclasses import dataclass, field

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from .config import settings

log = logging.getLogger("vault")


@dataclass
class Session:
    id: str
    created: float
    expires: float
    _blob: bytes = b""
    _nonce: bytes = b""
    # Données NON sensibles (déjà pseudonymisées) : utilisables en clair
    protected_text: str = ""
    history: list[dict] = field(default_factory=list)  # tours de chatbot, pseudonymisés
    last_result: dict | None = None
    document: dict | None = None  # PDF masqué (bytes) + aperçus
    access_log: list[dict] = field(default_factory=list)


class Vault:
    def __init__(self, key: bytes | None = None):
        self._aes = AESGCM(key or settings.vault_key())
        self._sessions: dict[str, Session] = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------- sessions
    def create(self) -> Session:
        now = time.time()
        sid = secrets.token_urlsafe(12)
        sess = Session(sid, now, now + settings.vault_ttl_seconds)
        self._write(sess, {"entries": {}, "counters": {}})
        with self._lock:
            self._sessions[sid] = sess
        return sess

    def get(self, sid: str | None) -> Session | None:
        if not sid:
            return None
        self.purge()
        with self._lock:
            return self._sessions.get(sid)

    def get_or_create(self, sid: str | None) -> Session:
        return self.get(sid) or self.create()

    def delete(self, sid: str) -> bool:
        with self._lock:
            return self._sessions.pop(sid, None) is not None

    def purge(self):
        now = time.time()
        with self._lock:
            for sid in [s for s, v in self._sessions.items() if v.expires < now]:
                del self._sessions[sid]

    # -------------------------------------------------------------- mapping
    def read_mapping(self, sess: Session) -> dict:
        data = self._aes.decrypt(sess._nonce, sess._blob, sess.id.encode())
        return json.loads(data)

    def write_mapping(self, sess: Session, mapping: dict):
        self._write(sess, mapping)

    def _write(self, sess: Session, mapping: dict):
        nonce = os.urandom(12)
        sess._blob = self._aes.encrypt(nonce, json.dumps(mapping, ensure_ascii=False).encode(), sess.id.encode())
        sess._nonce = nonce

    def audited_read(self, sess: Session, who: str) -> dict:
        entry = {"at": time.strftime("%Y-%m-%dT%H:%M:%S"), "by": who}
        sess.access_log.append(entry)
        # journal sans aucune valeur : uniquement qui et quand
        log.info("Lecture de la table de correspondance session=%s par=%s", sess.id, who)
        return self.read_mapping(sess)


vault = Vault()
