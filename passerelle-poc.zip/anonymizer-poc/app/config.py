"""Configuration centralisée, lue depuis les variables d'environnement.

Aucune clé n'est obligatoire : sans clé, le POC tourne entièrement en local
(classifieur lexical, LLM simulé) pour pouvoir être démontré hors ligne.
"""
from __future__ import annotations

import base64
import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _env_bool(name: str, default: bool) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "oui", "on"}


@dataclass
class Settings:
    # --- LLM externe (Mistral par défaut, API compatible OpenAI) ---
    llm_api_key: str | None = field(default_factory=lambda: os.getenv("MISTRAL_API_KEY") or os.getenv("LLM_API_KEY"))
    llm_base_url: str = field(default_factory=lambda: os.getenv("LLM_BASE_URL", "https://api.mistral.ai/v1"))
    llm_model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", "mistral-small-latest"))

    # --- LLM local (Ollama) pour le contenu bloqué ---
    ollama_url: str = field(default_factory=lambda: os.getenv("OLLAMA_URL", "http://localhost:11434"))
    ollama_model: str = field(default_factory=lambda: os.getenv("OLLAMA_MODEL", "mistral:7b-instruct"))

    # --- Jev (TypeSafe) ---
    jev_api_key: str | None = field(default_factory=lambda: os.getenv("TYPESAFE_API_KEY"))
    jev_url: str = field(default_factory=lambda: os.getenv("TYPESAFE_URL", "https://api.typesafe.ai/v1/systemone"))
    jev_model: str = field(default_factory=lambda: os.getenv("TYPESAFE_MODEL", "jev-latest"))

    # --- Détection ---
    use_gliner: bool = field(default_factory=lambda: _env_bool("USE_GLINER", True))
    gliner_model: str = field(default_factory=lambda: os.getenv("GLINER_MODEL", "urchade/gliner_multi_pii-v1"))
    gliner_threshold: float = field(default_factory=lambda: float(os.getenv("GLINER_THRESHOLD", "0.45")))
    spacy_model: str = field(default_factory=lambda: os.getenv("SPACY_MODEL", "fr_core_news_md"))
    tessdata: str = field(default_factory=lambda: os.getenv("TESSDATA_PREFIX", str(ROOT / "models" / "tessdata")))

    # --- Coffre (table de correspondance) ---
    vault_key_b64: str | None = field(default_factory=lambda: os.getenv("VAULT_KEY"))
    vault_ttl_seconds: int = field(default_factory=lambda: int(os.getenv("VAULT_TTL", "3600")))
    mapping_api_token: str = field(default_factory=lambda: os.getenv("MAPPING_API_TOKEN", "demo-token"))

    # --- Classifieur de sensibilité par défaut ---
    default_classifier: str = field(default_factory=lambda: os.getenv("CLASSIFIER", "lexical"))

    def vault_key(self) -> bytes:
        if self.vault_key_b64:
            key = base64.b64decode(self.vault_key_b64)
            if len(key) != 32:
                raise ValueError("VAULT_KEY doit être une clé AES-256 encodée en base64 (32 octets).")
            return key
        # Clé éphémère : la table est illisible après redémarrage, ce qui est voulu pour le POC.
        return os.urandom(32)


settings = Settings()
