"""Catalogue des entités, des stratégies et des profils métier.

C'est ce catalogue que l'API expose pour que l'appelant choisisse, au moment
de l'appel, quelles informations pseudonymiser et comment (tâche 1).
"""
from __future__ import annotations

# Familles affichées dans l'interface (ordre = ordre d'affichage)
FAMILIES = {
    "identite": "Identité et contact",
    "finance": "Identifiants bancaires et fiscaux",
    "metier": "Références de contrat et de dossier",
    "quasi": "Quasi-identifiants",
}

# entité -> (libellé, famille, stratégie par défaut, activée par défaut)
ENTITIES: dict[str, dict] = {
    "PERSONNE":        {"label": "Nom de personne",          "family": "identite", "strategy": "pseudonyme",     "default": True},
    "EMAIL":           {"label": "Adresse e-mail",            "family": "identite", "strategy": "pseudonyme",     "default": True},
    "TELEPHONE":       {"label": "Téléphone",                 "family": "identite", "strategy": "pseudonyme",     "default": True},
    "ADRESSE":         {"label": "Adresse postale",           "family": "identite", "strategy": "pseudonyme",     "default": True},
    "NIR":             {"label": "N° de sécurité sociale",    "family": "identite", "strategy": "pseudonyme",     "default": True},
    "PIECE_IDENTITE":  {"label": "Passeport / CNI",           "family": "identite", "strategy": "pseudonyme",     "default": True},
    "IBAN":            {"label": "IBAN",                      "family": "finance",  "strategy": "pseudonyme",     "default": True},
    "BIC":             {"label": "BIC",                       "family": "finance",  "strategy": "pseudonyme",     "default": True},
    "CARTE_BANCAIRE":  {"label": "Carte bancaire",            "family": "finance",  "strategy": "pseudonyme",     "default": True},
    "SIRET":           {"label": "SIRET / SIREN",             "family": "finance",  "strategy": "pseudonyme",     "default": True},
    "NUM_CONTRAT":     {"label": "N° de contrat",             "family": "metier",   "strategy": "pseudonyme",     "default": True},
    "NUM_POLICE":      {"label": "N° de police",              "family": "metier",   "strategy": "pseudonyme",     "default": True},
    "NUM_CLIENT":      {"label": "N° client / adhérent",      "family": "metier",   "strategy": "pseudonyme",     "default": True},
    "NUM_DOSSIER":     {"label": "Réf. de dossier",           "family": "metier",   "strategy": "pseudonyme",     "default": True},
    "PLAQUE":          {"label": "Immatriculation",           "family": "metier",   "strategy": "pseudonyme",     "default": True},
    "DATE_NAISSANCE":  {"label": "Date de naissance",         "family": "quasi",    "strategy": "generalisation", "default": True},
    "DATE":            {"label": "Autre date",                "family": "quasi",    "strategy": "conserver",      "default": False},
    "ORGANISATION":    {"label": "Employeur / organisation",  "family": "quasi",    "strategy": "pseudonyme",     "default": True},
    "LIEU":            {"label": "Ville / lieu",              "family": "quasi",    "strategy": "generalisation", "default": True},
    "IP":              {"label": "Adresse IP",                "family": "quasi",    "strategy": "pseudonyme",     "default": True},
}

STRATEGIES = {
    "pseudonyme": "Jeton typé réversible, ex. [PERSONNE_1]",
    "generalisation": "Valeur rendue moins précise (tranche d'âge, département, mois)",
    "suppression": "Remplacée par [INFORMATION RETIRÉE], irréversible",
    "conserver": "Laissée en clair",
}

# Catégories sensibles (couche sens)
SENSITIVE_CATEGORIES = {
    "SANTE":      {"label": "Santé physique ou mentale",         "level": "tres_sensible"},
    "FINANCES":   {"label": "Situation financière",              "level": "sensible"},
    "FAMILLE":    {"label": "Vie familiale et conjugale",        "level": "sensible"},
    "JUDICIAIRE": {"label": "Situation judiciaire",              "level": "tres_sensible"},
    "ART9":       {"label": "Religion, opinions, orientation, origine, syndicat", "level": "tres_sensible"},
}

# Profils métier : décident de la colonne « nécessaire à la tâche »
BUSINESS_PROFILES = {
    "gestion_contrats": {
        "label": "Gestion de contrats",
        "scope": "répondre aux questions sur les contrats du client : garanties, échéances, résiliation, avenants, documents",
        "needed": [],
    },
    "recouvrement": {
        "label": "Recouvrement / impayés",
        "scope": "trouver une solution de paiement pour une facture ou une échéance impayée : échéancier, report, moyens de paiement",
        "needed": ["FINANCES"],
    },
    "assurance": {
        "label": "Assurance (sinistres)",
        "scope": "accompagner la déclaration et le suivi d'un sinistre, expliquer les garanties et les pièces à fournir",
        "needed": ["SANTE", "FAMILLE"],
    },
    "banque": {
        "label": "Banque de détail",
        "scope": "répondre aux questions sur les comptes, cartes, virements, crédits et frais bancaires",
        "needed": ["FINANCES"],
    },
}

TEMPLATES = {
    "SANTE": "Le client évoque un problème de santé.",
    "FINANCES": "Le client signale une difficulté financière.",
    "FAMILLE": "Le client évoque un changement dans sa situation familiale.",
    "JUDICIAIRE": "Le client mentionne une situation d'ordre judiciaire.",
    "ART9": "Le client mentionne une information relevant de sa vie privée.",
}
REMOVED_MARKER = "[information personnelle retirée]"


def default_entities() -> list[str]:
    return [k for k, v in ENTITIES.items() if v["default"]]


def default_strategies() -> dict[str, str]:
    return {k: v["strategy"] for k, v in ENTITIES.items()}
