#!/usr/bin/env bash
# Lance la passerelle : http://localhost:8000  (API : http://localhost:8000/docs)
set -euo pipefail
cd "$(dirname "$0")"
if [ -f .env ]; then set -a; . ./.env; set +a; fi
python -m spacy info fr_core_news_md >/dev/null 2>&1 || python -m spacy download fr_core_news_md
[ -f eval/data/contrat_fictif_natif.pdf ] || python -m eval.make_fixtures
exec python -m uvicorn app.main:app --host 0.0.0.0 --port "${PORT:-8000}"
